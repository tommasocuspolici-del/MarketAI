# Versioning e Dipendenze

> ⚠️ **LEGGERE** `.claude/05_dependencies.md` per la lista completa con versioni pinnate.
> Questo file documenta l'evoluzione delle versioni e le regole di gestione dipendenze.

---

## Versioni di MarketAI

### v11.0.0 — Infrastruttura (18/08/2026 → 06/09/2026)
**Stato:** Pianificato — in implementazione con Claude Code Opus 4.8
- Installer v3 con GUI tkinter (`scripts/install_v3.py`)
- Management UI con system tray (`management_ui.py`) — ZERO import interni
- CLAUDE.md v2 con mappa 40+ pagine e vincoli Python documentati
- Aggiunta dipendenze: `pystray ^0.19`, `Pillow ^10.0`

### v12.0.0 — Consolidamento (Settembre 2026)
**Stato:** Pianificato
- Data Provider Plugin System (interfaccia ABC + ProviderRegistry)
- Provider: YFinanceProvider, AlphaVantageProvider, FinnhubProvider
- Logging JSON strutturato, rotazione log 20MB
- GitHub Actions CI/CD automatico
- MkDocs Material documentazione
- Aggiunta dipendenze: `mkdocs-material ^9.5`

### v13.0.0 — Modellistica Avanzata (Ottobre 2026)
**Stato:** Pianificato
- EnsemblePredictor (3 strategie: average, weighted, stacking)
- XGBoost + RandomForest con Quantile Regression (Q10–Q90)
- FeatureBuilder automatizzato (lag, rolling, Fourier, selezione)
- Fan chart probabilistico in Q1_Backtesting

### v14.0.0 — Modelli Avanzati (Novembre 2026)
**Stato:** Pianificato
- N-BEATS PyTorch CPU-only (ROCm non stabile su RX 6700)
- RealisticBacktester con commissioni/slippage reali (≥ 0.001)
- Metriche avanzate: SMAPE, Theil's U2, Pinball Loss, CRPS
- FastAPI backend: `/predict`, `/backtest`, `/models`, `/health`
- Aggiunta dipendenze: `fastapi ^0.111`, `uvicorn[standard] ^0.30`, `psutil ^5.9`

### v15.0.0 — UI Nativa (Dicembre 2026)
**Stato:** Pianificato
- Shell pywebview: finestra nativa Windows senza browser visibile
- Persistenza sessioni su `db/user_sessions.db` (SQLite separato)
- Model drift detection con alert passivi in S2_Settings
- Pagina H1_Cronologia: storico analisi + export/import JSON
- Build `MarketAI.exe` con PyInstaller
- Aggiunta dipendenze: `pywebview ^5.1`

---

## ⚠️ Dipendenze Pinnate — NON MODIFICARE

| Pacchetto | Versione | Motivo |
|---|---|---|
| `yfinance` | `==0.2.54` | 0.2.55+ crash websockets |
| `websockets` | `>=12.0,<13.0` | 13.x incompatibile con yfinance |
| `pandera` | `>=0.18,<1.0` | Namespace split in 1.x |

---

## Regole di Gestione Dipendenze

1. **Non eseguire mai `poetry update`** senza pianificazione esplicita
2. Aggiornare pyproject.toml SOLO nelle sessioni di roadmap indicate
3. Dopo qualsiasi modifica: `poetry run pytest -m regression -q` → 0 failed
4. Le versioni in `poetry.lock` sono la sorgente di verità
5. Per verificare versioni attive: `poetry show yfinance websockets pandera`

## Semantic Versioning

```
MAJOR.MINOR.PATCH
MAJOR = breaking changes (architettura, contratti API)
MINOR = nuove feature retrocompatibili
PATCH = bug fix
```

## Hardware di Riferimento (vincola scelte tecniche)

```
CPU:  Ryzen 5 5600 — torch.set_num_threads(4) per N-BEATS
GPU:  RX 6700 8GB — ROCm instabile su Windows → CPU only per PyTorch
RAM:  16GB — max batch_size=64 per DL, max hidden_size=256 per N-BEATS
SSD:  512GB — DuckDB 20 anni prezzi ~50GB stimati
```

**Vincolo assoluto:** Nessun training PyTorch su GPU. `tree_method="hist"` per XGBoost.
