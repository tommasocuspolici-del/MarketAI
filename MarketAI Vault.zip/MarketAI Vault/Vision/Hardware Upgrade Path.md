# 🖥️ Hardware Upgrade Path — MarketAI 2027

> Riferimento rapido per decisioni hardware durante lo sviluppo.
> File completo: [[6 - visione 2027]]

---

## Stato Attuale

| Componente | Spec | Rating MarketAI |
|------------|------|-----------------|
| CPU | Ryzen 5 5600 (6C/12T) | 🟡 Sufficiente |
| GPU | RX 6700 8GB VRAM | 🔴 ROCm instabile → CPU fallback |
| RAM | 16GB DDR4 3200MHz | 🟠 Limitante per AI layer |
| SSD | 512GB NVMe | 🟡 Sufficiente 2-3 anni |

---

## Upgrade A — RAM 32GB (~80 EUR) ← PRIORITÀ MASSIMA

**Quando fare:** prima di iniziare v17.0.0 (LLM + RAG)

**Sblocca:**
- Ollama + mistral:7b in inferenza (~8GB RAM)
- Training PatchTST su dataset medi
- Sessioni v17 completamente funzionanti
- `require_ram(min_gb=6.0)` in `ollama_client.py` non bloccerà

**Verifica post-upgrade:** `psutil.virtual_memory().total / 1e9` → deve essere ≥ 30GB

---

## Upgrade B — RTX 4060 8GB (~300 EUR) ← Consigliato 6-12 mesi

**Quando fare:** post-v15, prima di v17 se possibile

**Motivo:** RX 6700 inutilizzabile per DL su Windows (ROCm 6.x non stabile)

**Sblocca:**
- N-BEATS GPU: ~30 secondi vs ~5 minuti CPU
- LSTM/GRU training stabile
- mistral:7b-q4 su GPU (~5GB VRAM) → inferenza veloce
- `torch.device("cuda")` finalmente stabile

**Cambio codice richiesto:** `nbeats_model.py` → rimuovere `torch.device("cpu")` hardcoded → usare feature flag `pytorch_gpu: true`

---

## Upgrade C — RTX 4060 Ti 16GB (~500 EUR) ← Opzionale 12-24 mesi

**Quando fare:** solo se LLM locale diventa uso primario

**Sblocca:**
- mistral:7b fp16 senza quantizzazione (14GB VRAM)
- FinGPT fine-tuning su dati personali
- Temporal Fusion Transformer completo

---

## Costi vs Benefici

```
Upgrade A (RAM):   ~80 EUR → sblocca tutto AI layer
Upgrade B (GPU):   ~300 EUR → DL 10x più veloce
Upgrade C (GPU+):  ~500 EUR → LLM full precision
TOTALE:            ~880 EUR su 2 anni

Bloomberg Terminal: $24,000/ANNO
Risparmio 2 anni:  ~$47,000
```

---

*Vedi [[6 - visione 2027]] per il piano completo*
*Hardware corrente: feature flag `pytorch_gpu: false` SEMPRE su RX 6700*
