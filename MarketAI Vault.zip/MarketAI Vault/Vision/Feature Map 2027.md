# 🗺️ Feature Map 2027 — Cosa Aggiungere e Quando

> Mappa rapida delle nuove feature post-v15.
> Per dettaglio sessioni: [[6 - visione 2027]]

---

## v16.0.0 — Feature Differenzianti (feb–apr 2027)

| # | Feature | Sessione | Dipendenze | Hardware |
|---|---------|----------|------------|----------|
| F1 | Telegram Bot alerts | 1 | python-telegram-bot, aiohttp | Attuale |
| F2 | Options Chain + Greeks | 2 | yfinance (già), scipy (già) | Attuale |
| F3 | Alt Data (GTrends, Reddit, Wikipedia) | 3 | pytrends, praw | Attuale |
| F4 | Multi-Broker Import (Degiro, Fineco, T212) | 4 | pdfplumber, openpyxl | Attuale |
| F5 | PDF Report Automatico Settimanale | 5 | WeasyPrint (già), Jinja2 (già) | Attuale |
| F6 | Factor Analysis Fama-French 5 | 6 | pandas-datareader (già), statsmodels (già) | Attuale |

**Aggiungere a pyproject.toml in v16:**
```toml
python-telegram-bot = "^21.0"
pytrends = "^4.9"
praw = "^7.7"           # Reddit API
pdfplumber = "^0.11"    # PDF Fineco
```

---

## v17.0.0 — Terminale Istituzionale (mag–dic 2027)

| # | Feature | Sessione | Dipendenze | Hardware |
|---|---------|----------|------------|----------|
| AI1 | Ollama + RAG (LLM locale) | 1 | aiohttp (già), sentence-transformers | **32GB RAM** |
| AI2 | Black-Litterman + HRP Optimizer | 2 | cvxpy (già), scipy (già) | 32GB RAM |
| AI3 | Risk Istituzionale (Kelly, LVaR, Factor) | 3 | scipy (già), statsmodels (già) | 32GB RAM |
| AI4 | Regime-Conditional Allocation | 4 | cvxpy (già), hmmlearn (già) | 32GB RAM |
| AI5 | Event Study Engine (Abnormal Returns) | 5 | statsmodels (già) | 32GB RAM |
| AI6 | Validazione + CLAUDE.md v3 | 6 | — | 32GB RAM |

**Aggiungere a pyproject.toml in v17:**
```toml
sentence-transformers = "^3.0"  # embedding per RAG
chromadb = "^0.5"               # vector store locale
# Ollama: installare separatamente (non via pip)
```

---

## Pagine Dashboard Nuove

| Pagina | Versione | Categoria |
|--------|----------|-----------|
| `O1_Options_Chain.py` | v16 | Engine |
| `O2_Volatility_Surface.py` | v16 | Engine |
| `Q_Factor_Analysis.py` | v16 | Engine |
| `AI1_Analyst.py` | v17 | AI |
| `Q_Risk_Dashboard.py` (espansione) | v17 | Engine |
| `Q_Regime_Allocation.py` | v17 | Engine |

---

## Feature Flags da Aggiungere

```yaml
# config/feature_flags.yaml — aggiungere in v16:
telegram_alerts: false          # configurare TELEGRAM_BOT_TOKEN in .env
options_chain: true             # yfinance già supporta, no RAM aggiuntiva
alt_data_sources: false         # pytrends/PRAW: API pesanti, opt-in

# aggiungere in v17:
ollama_narrative: false         # RICHIEDE 32GB RAM + Ollama installato
rag_on_documents: false         # RICHIEDE ollama_narrative: true
black_litterman: true           # cvxpy già in stack
regime_conditional_alloc: true  # HMM già presente
```

---

## Integrazioni con Moduli Esistenti

```
TelegramNotifier → integra con:
  · engine/alerts/ (già esiste) → notifiche push
  · DriftDetector (v15) → alert degradazione modelli
  · APScheduler → report settimanale PDF

OptionsFetcher → integra con:
  · E7_Sentiment → Put/Call ratio come fonte sentiment
  · E5_Forex_Options → già parzialmente presente

AltDataScore → integra con:
  · E7_Sentiment → sezione "Alternative Data" nel radar
  · K1_Composite_Signal → peso aggiuntivo nel segnale composito

FFFactorModel → integra con:
  · P2_Portfolio → attribuzione rendimenti per fattore
  · Q_Risk_Dashboard → decomposizione rischio fattoriale

BlackLitterman → integra con:
  · P6_Profilo_Investitore → view dell'investitore input
  · P7_Scenari_Ricchezza → scenari con allocazione ottimale
```

---

*Feature Map 2027 · MarketAI Vision*
*Aggiornato: Giugno 2026*
