"""
MarketAI Installer v3
=====================
Migra il progetto verso %APPDATA%\\MarketAI\\ e ricrea il venv con Python 3.12.10.
NON sovrascrive scripts/install.py (v1).

Uso:
    python scripts/install_v3.py          # GUI interattiva (default)
    python scripts/install_v3.py --cli    # Solo terminale, no GUI
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
import tkinter as tk
import zipfile
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, scrolledtext, ttk
from typing import Callable

# ──────────────────────────────────────────────
# CONFIGURAZIONE
# ──────────────────────────────────────────────
APP_NAME = "MarketAI"
APP_VERSION = "v11.0.0"

PYTHON_312_CANDIDATES = [
    r"C:\Users\{user}\AppData\Local\Programs\Python\Python312\python.exe",
    r"C:\Python312\python.exe",
    r"C:\Program Files\Python312\python.exe",
    r"C:\Program Files (x86)\Python312\python.exe",
]

EXCLUDE_PATTERNS: set[str] = {
    ".venv", "venv", "__pycache__", ".hypothesis",
    ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".coverage", "htmlcov", "dist", "build",
    "*.egg-info", "*.pyc", "*.pyo",
    "data/cache", "db/*.wal",
    "MarketAI.exe", "MarketAI_Manager.exe",
    "*.log",
}

CREATE_NO_WINDOW = 0x08000000   # subprocess senza finestra cmd su Windows


# ──────────────────────────────────────────────
# UTILITY FUNCTIONS
# ──────────────────────────────────────────────

def get_source_path() -> Path:
    """Cartella del progetto corrente (parent di scripts/)."""
    return Path(__file__).parent.parent.resolve()


def get_target_path() -> Path:
    """Destinazione: %APPDATA%\\MarketAI\\"""
    appdata = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    return appdata / APP_NAME


def get_backup_path() -> Path:
    """Backup: %LOCALAPPDATA%\\MarketAI\\backups\\"""
    localappdata = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    return localappdata / APP_NAME / "backups"


def _should_exclude(path: Path, src_root: Path) -> bool:
    """True se il path deve essere escluso dalla copia."""
    rel = path.relative_to(src_root)
    parts = rel.parts
    for pattern in EXCLUDE_PATTERNS:
        if "*" in pattern:
            name_pattern = pattern.lstrip("*/")
            if path.match(pattern) or path.name.endswith(name_pattern.lstrip("*")):
                return True
        else:
            if pattern in parts:
                return True
    return False


# ──────────────────────────────────────────────
# STEP 1 — PREREQUISITI
# ──────────────────────────────────────────────

def find_python_312() -> str | None:
    """Cerca Python 3.12.x. Ritorna il path se trovato, None altrimenti."""
    username = os.environ.get("USERNAME", "")

    # 1. Percorsi comuni Windows
    candidates = [c.format(user=username) for c in PYTHON_312_CANDIDATES]
    for path in candidates:
        p = Path(path)
        if p.exists():
            try:
                result = subprocess.run(
                    [str(p), "--version"], capture_output=True, text=True, timeout=5
                )
                if "3.12." in result.stdout + result.stderr:
                    return str(p)
            except Exception:
                continue

    # 2. py launcher (Windows)
    try:
        result = subprocess.run(
            ["py", "-3.12", "-c", "import sys; print(sys.executable)"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except Exception:
        pass

    # 3. python3.12 in PATH (Linux/Mac fallback)
    try:
        result = subprocess.run(
            ["python3.12", "-c", "import sys; print(sys.executable)"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass

    return None


def check_poetry() -> str | None:
    """Verifica Poetry installato. Ritorna versione stringa o None."""
    try:
        result = subprocess.run(
            ["poetry", "--version"], capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None


def check_git() -> bool:
    """Verifica Git installato."""
    try:
        result = subprocess.run(
            ["git", "--version"], capture_output=True, text=True, timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


def install_poetry(log_fn: Callable[[str], None]) -> bool:
    """Installa Poetry tramite installer ufficiale."""
    try:
        import urllib.request
        log_fn("📥 Download Poetry installer...")
        url = "https://install.python-poetry.org"
        installer_path = Path.home() / "install-poetry.py"
        urllib.request.urlretrieve(url, str(installer_path))
        log_fn("⚙️  Esecuzione Poetry installer...")
        result = subprocess.run(
            [sys.executable, str(installer_path)],
            capture_output=True, text=True, timeout=300
        )
        installer_path.unlink(missing_ok=True)
        if result.returncode == 0:
            log_fn("✅ Poetry installato.")
            return True
        else:
            log_fn(f"❌ Poetry install fallito:\n{result.stderr[:500]}")
            return False
    except Exception as e:
        log_fn(f"❌ Errore installazione Poetry: {e}")
        return False


# ──────────────────────────────────────────────
# STEP 2 — COPIA PROGETTO
# ──────────────────────────────────────────────

def calculate_files_to_copy(src: Path) -> list[Path]:
    """Lista tutti i file da copiare (esclusi i pattern)."""
    files = []
    for f in src.rglob("*"):
        if f.is_file() and not _should_exclude(f, src):
            files.append(f)
    return files


def copy_project(
    src: Path,
    dst: Path,
    progress_cb: Callable[[int, int, str], None] | None = None,
) -> tuple[int, int]:
    """
    Copia src → dst escludendo EXCLUDE_PATTERNS.
    progress_cb(files_done, files_total, current_filename)
    Ritorna (files_copied, files_skipped).
    """
    files = calculate_files_to_copy(src)
    total = len(files)
    copied = 0
    skipped = 0

    dst.mkdir(parents=True, exist_ok=True)

    for i, src_file in enumerate(files):
        rel = src_file.relative_to(src)
        dst_file = dst / rel
        try:
            dst_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_file, dst_file)
            copied += 1
        except Exception:
            skipped += 1

        if progress_cb:
            progress_cb(i + 1, total, src_file.name)

    return copied, skipped


def copy_env_file(src: Path, dst: Path) -> bool:
    """Copia .env dalla sorgente alla destinazione."""
    src_env = src / ".env"
    dst_env = dst / ".env"
    if src_env.exists():
        shutil.copy2(src_env, dst_env)
        return True
    src_example = src / ".env.example"
    if src_example.exists():
        shutil.copy2(src_example, dst_env)
        return True
    return False


# ──────────────────────────────────────────────
# STEP 3 — VENV
# ──────────────────────────────────────────────

def recreate_venv(
    project_path: Path,
    python_312_path: str,
    log_fn: Callable[[str], None],
) -> bool:
    """Ricrea il venv con Python 3.12.10 e installa le dipendenze."""
    try:
        # Rimuovi venv esistente (potrebbe essere 3.14 corrotto)
        log_fn("🗑️  Rimozione venv esistente (se presente)...")
        subprocess.run(
            ["poetry", "env", "remove", "--all"],
            cwd=str(project_path),
            capture_output=True,
            creationflags=CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=60,
        )

        # Imposta Python 3.12
        log_fn(f"🐍 Configuro Python 3.12: {python_312_path}")
        result = subprocess.run(
            ["poetry", "env", "use", python_312_path],
            cwd=str(project_path),
            capture_output=True, text=True,
            creationflags=CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=60,
        )
        if result.returncode != 0:
            log_fn(f"❌ poetry env use fallito:\n{result.stderr[:300]}")
            return False

        # Installa dipendenze
        log_fn("📦 Installazione dipendenze (poetry install) — può richiedere 3-5 minuti...")
        result = subprocess.run(
            ["poetry", "install", "--no-interaction"],
            cwd=str(project_path),
            capture_output=True, text=True,
            creationflags=CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=600,
        )
        if result.returncode != 0:
            log_fn(f"❌ poetry install fallito:\n{result.stderr[:500]}")
            return False

        # Verifica versione Python
        result = subprocess.run(
            ["poetry", "run", "python", "--version"],
            cwd=str(project_path),
            capture_output=True, text=True,
            creationflags=CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=30,
        )
        version_str = result.stdout.strip() + result.stderr.strip()
        if "3.12." not in version_str:
            log_fn(f"⚠️  Attenzione: versione Python nel venv: {version_str}")
        else:
            log_fn(f"✅ Venv configurato con {version_str}")

        return True

    except Exception as e:
        log_fn(f"❌ Errore setup venv: {e}")
        return False


# ──────────────────────────────────────────────
# STEP 4 — INIT DATABASE
# ──────────────────────────────────────────────

def init_database(project_path: Path, log_fn: Callable[[str], None]) -> bool:
    """Inizializza DuckDB e SQLite tramite scripts/init_database.py."""
    init_script = project_path / "scripts" / "init_database.py"
    if not init_script.exists():
        log_fn("⚠️  scripts/init_database.py non trovato — skip init DB.")
        return True  # Non bloccante

    try:
        log_fn("🗄️  Inizializzazione database...")
        result = subprocess.run(
            ["poetry", "run", "python", str(init_script)],
            cwd=str(project_path),
            capture_output=True, text=True,
            creationflags=CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=120,
        )
        if result.returncode != 0:
            log_fn(f"⚠️  Init DB warning (non critico):\n{result.stderr[:300]}")
        else:
            log_fn("✅ Database inizializzato.")
        return True
    except Exception as e:
        log_fn(f"⚠️  Init DB skipped ({e}) — non critico.")
        return True


# ──────────────────────────────────────────────
# STEP 5 — SHORTCUT DESKTOP
# ──────────────────────────────────────────────

def create_desktop_shortcut(project_path: Path, log_fn: Callable[[str], None]) -> bool:
    """Crea MarketAI_start.bat sul Desktop."""
    try:
        desktop = Path.home() / "Desktop"
        if not desktop.exists():
            # Prova OneDrive Desktop
            desktop = Path.home() / "OneDrive" / "Desktop"
        if not desktop.exists():
            log_fn("⚠️  Desktop non trovato — shortcut non creato.")
            return False

        bat_path = desktop / "MarketAI.bat"
        bat_content = f"""@echo off
title MarketAI Professional
cd /d "{project_path}"
echo Avvio MarketAI...
poetry run python launcher.py
pause
"""
        bat_path.write_text(bat_content, encoding="utf-8")
        log_fn(f"✅ Shortcut creato: {bat_path}")
        return True
    except Exception as e:
        log_fn(f"⚠️  Shortcut non creato: {e}")
        return False


# ──────────────────────────────────────────────
# STEP 6 — SMOKE TEST
# ──────────────────────────────────────────────

def run_smoke_tests(project_path: Path, log_fn: Callable[[str], None]) -> bool:
    """Esegue pytest -m regression per verificare l'installazione."""
    log_fn("🧪 Verifica installazione (pytest -m regression)...")
    try:
        result = subprocess.run(
            ["poetry", "run", "pytest", "-m", "regression", "-q", "--tb=short"],
            cwd=str(project_path),
            capture_output=True, text=True,
            creationflags=CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=180,
        )
        output = result.stdout + result.stderr
        # Mostra ultime righe del risultato
        lines = [l for l in output.split("\n") if l.strip()]
        for line in lines[-10:]:
            log_fn(f"  {line}")

        if "failed" in output.lower() and result.returncode != 0:
            log_fn("⚠️  Alcuni test falliti — verificare manualmente.")
            return False
        else:
            log_fn("✅ Smoke test superati.")
            return True
    except Exception as e:
        log_fn(f"⚠️  Smoke test skipped ({e}).")
        return True  # Non bloccante


# ──────────────────────────────────────────────
# ORCHESTRATORE (usato da GUI e CLI)
# ──────────────────────────────────────────────

def run_installation(
    log_fn: Callable[[str], None],
    progress_fn: Callable[[float], None],  # 0.0 → 1.0
) -> bool:
    """
    Esegue tutti gli step di installazione in sequenza.
    Ritorna True se completato con successo.
    """
    src = get_source_path()
    dst = get_target_path()

    log_fn(f"{'='*50}")
    log_fn(f"  {APP_NAME} {APP_VERSION} — Installer v3")
    log_fn(f"{'='*50}")
    log_fn(f"  Sorgente:    {src}")
    log_fn(f"  Destinazione:{dst}")
    log_fn(f"{'='*50}\n")

    # STEP 1 — Prerequisiti
    log_fn("── STEP 1/6: Verifica prerequisiti ──")
    progress_fn(0.0)

    python_312 = find_python_312()
    if not python_312:
        log_fn("❌ Python 3.12 non trovato!")
        log_fn("   Scaricare da: https://www.python.org/downloads/release/python-31210/")
        log_fn("   Installare Python 3.12.x e riprovare.")
        return False
    log_fn(f"✅ Python 3.12 trovato: {python_312}")

    if not check_git():
        log_fn("⚠️  Git non trovato — push GitHub non disponibile.")
    else:
        log_fn("✅ Git disponibile.")

    poetry_version = check_poetry()
    if not poetry_version:
        log_fn("⚠️  Poetry non trovato. Installazione automatica...")
        if not install_poetry(log_fn):
            log_fn("❌ Installazione Poetry fallita. Installare manualmente da:")
            log_fn("   https://python-poetry.org/docs/#installation")
            return False
    else:
        log_fn(f"✅ {poetry_version}")

    progress_fn(0.15)

    # STEP 2 — Copia progetto
    log_fn("\n── STEP 2/6: Copia progetto → AppData ──")

    if dst.exists() and (dst / "pyproject.toml").exists():
        log_fn(f"ℹ️  Installazione precedente trovata in {dst}.")
        log_fn("   I file verranno aggiornati (sovrascrittura).")

    def copy_progress(done: int, total: int, filename: str) -> None:
        progress_fn(0.15 + 0.35 * (done / max(total, 1)))

    copied, skipped = copy_project(src, dst, progress_cb=copy_progress)
    log_fn(f"✅ {copied} file copiati, {skipped} skipped.")

    # Copia .env
    if copy_env_file(src, dst):
        log_fn("✅ .env copiato (API keys preservate).")
    else:
        log_fn("⚠️  .env non trovato — configurare manualmente dopo l'installazione.")

    progress_fn(0.50)

    # STEP 3 — Venv
    log_fn("\n── STEP 3/6: Ambiente Python 3.12 ──")
    if not recreate_venv(dst, python_312, log_fn):
        log_fn("❌ Setup venv fallito. Installazione interrotta.")
        return False
    progress_fn(0.70)

    # STEP 4 — DB Init
    log_fn("\n── STEP 4/6: Inizializzazione database ──")
    init_database(dst, log_fn)
    progress_fn(0.80)

    # STEP 5 — Shortcut
    log_fn("\n── STEP 5/6: Shortcut Desktop ──")
    create_desktop_shortcut(dst, log_fn)
    progress_fn(0.88)

    # STEP 6 — Smoke test
    log_fn("\n── STEP 6/6: Verifica installazione ──")
    run_smoke_tests(dst, log_fn)
    progress_fn(1.0)

    log_fn(f"\n{'='*50}")
    log_fn(f"  ✅ INSTALLAZIONE COMPLETATA!")
    log_fn(f"  Progetto installato in: {dst}")
    log_fn(f"  Avvia dal Desktop: MarketAI.bat")
    log_fn(f"  oppure: cd {dst} && poetry run python launcher.py")
    log_fn(f"{'='*50}")
    return True


# ──────────────────────────────────────────────
# GUI TKINTER
# ──────────────────────────────────────────────

class InstallerApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} Installer {APP_VERSION}")
        self.geometry("620x480")
        self.resizable(False, False)

        # Colori
        BG = "#1e1e2e"
        FG = "#cdd6f4"
        ACCENT = "#89b4fa"
        GREEN = "#a6e3a1"
        RED = "#f38ba8"

        self.configure(bg=BG)

        # Titolo
        tk.Label(
            self, text=f"🚀 {APP_NAME} Installer {APP_VERSION}",
            font=("Segoe UI", 14, "bold"), bg=BG, fg=ACCENT
        ).pack(pady=(18, 4))

        src = get_source_path()
        dst = get_target_path()
        tk.Label(
            self, text=f"Da: {src}\nA:  {dst}",
            font=("Segoe UI", 8), bg=BG, fg=FG, justify="left"
        ).pack(padx=20, pady=(0, 10))

        # Progress bar
        self._progress_var = tk.DoubleVar(value=0.0)
        self._progress_bar = ttk.Progressbar(
            self, variable=self._progress_var,
            maximum=1.0, length=560, mode="determinate"
        )
        self._progress_bar.pack(padx=30, pady=(0, 6))

        self._status_label = tk.Label(
            self, text="Pronto.", font=("Segoe UI", 9),
            bg=BG, fg=FG
        )
        self._status_label.pack()

        # Log area
        self._log = scrolledtext.ScrolledText(
            self, font=("Consolas", 8), bg="#181825", fg=FG,
            height=16, state="disabled", relief="flat", bd=0
        )
        self._log.pack(padx=16, pady=10, fill="both", expand=True)

        # Bottoni
        btn_frame = tk.Frame(self, bg=BG)
        btn_frame.pack(pady=(0, 16))
        self._install_btn = tk.Button(
            btn_frame, text="  ⬇  INSTALLA  ",
            font=("Segoe UI", 10, "bold"),
            bg=ACCENT, fg="#1e1e2e", relief="flat",
            activebackground=GREEN,
            command=self._start_install, padx=16, pady=6
        )
        self._install_btn.pack(side="left", padx=8)

        tk.Button(
            btn_frame, text="  ✖  Chiudi  ",
            font=("Segoe UI", 10),
            bg="#313244", fg=FG, relief="flat",
            command=self.destroy, padx=12, pady=6
        ).pack(side="left", padx=8)

    def _log_message(self, msg: str) -> None:
        self._log.configure(state="normal")
        self._log.insert("end", msg + "\n")
        self._log.see("end")
        self._log.configure(state="disabled")
        self._status_label.configure(text=msg[:80])
        self.update_idletasks()

    def _set_progress(self, value: float) -> None:
        self._progress_var.set(value)
        self.update_idletasks()

    def _start_install(self) -> None:
        self._install_btn.configure(state="disabled", text="  ⏳ Installazione...")
        thread = threading.Thread(target=self._run_install_thread, daemon=True)
        thread.start()

    def _run_install_thread(self) -> None:
        success = run_installation(
            log_fn=self._log_message,
            progress_fn=self._set_progress,
        )
        if success:
            self.after(0, lambda: messagebox.showinfo(
                "Installazione Completata",
                f"✅ {APP_NAME} è stato installato con successo!\n\n"
                "Avvia dal Desktop: MarketAI.bat"
            ))
        else:
            self.after(0, lambda: messagebox.showerror(
                "Installazione Fallita",
                "❌ Installazione non completata.\n"
                "Controlla il log per i dettagli."
            ))
        self.after(0, lambda: self._install_btn.configure(
            state="normal", text="  ⬇  REINSTALLA  "
        ))


# ──────────────────────────────────────────────
# CLI MODE
# ──────────────────────────────────────────────

def run_cli() -> None:
    """Modalità CLI senza GUI."""
    def log_fn(msg: str) -> None:
        print(msg, flush=True)

    def progress_fn(value: float) -> None:
        bar_len = 40
        filled = int(bar_len * value)
        bar = "█" * filled + "░" * (bar_len - filled)
        print(f"\r[{bar}] {int(value*100)}%", end="", flush=True)
        if value >= 1.0:
            print()

    success = run_installation(log_fn=log_fn, progress_fn=progress_fn)
    sys.exit(0 if success else 1)


# ──────────────────────────────────────────────
# ENTRY POINT
# ──────────────────────────────────────────────

if __name__ == "__main__":
    if "--cli" in sys.argv:
        run_cli()
    else:
        app = InstallerApp()
        app.mainloop()
