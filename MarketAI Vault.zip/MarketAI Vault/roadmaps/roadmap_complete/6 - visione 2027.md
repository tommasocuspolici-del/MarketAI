# 🏦 MarketAI — Visione 2027 · Roadmap Espansione Post-v15
> **v15.0.0 → v17.0.0** · Dal terminale personale al terminale istituzionale
> Pianificazione: Claude Sonnet 4.6 · Giugno 2026
> Implementazione: Claude Code Pro (Opus 4.8)
> Hardware attuale: Ryzen 5 5600 · RX 6700 8GB · 16GB RAM · 512GB NVMe

---

## ⚠️ PREREQUISITO ASSOLUTO

> **Non iniziare questa roadmap prima che v15.0.0 sia completato al 100%.**
> Gate obbligatorio: `poetry run pytest -m regression -q` → 0 failed
> Progetto in `%APPDATA%\MarketAI\`, avviabile con un click, Management UI funzionante.

---

## 📊 Stato Previsto a Fine v15 (Dicembre 2026)

| Componente | Stato |
|------------|-------|
| Installer + Management UI | ✅ v11 |
| Provider Plugin System + CI/CD | ✅ v12 |
| Ensemble + FeatureBuilder + Quantile | ✅ v13 |
| N-BEATS + FastAPI + RealisticBacktester | ✅ v14 |
| pywebview + Sessioni + Drift Detection | ✅ v15 |
| **Alternative Data** | ❌ da fare |
| **Options Analytics** | ❌ da fare |
| **Telegram Alerting** | ❌ da fare |
| **LLM locale (Ollama)** | ❌ da fare |
| **Multi-broker import** | ❌ da fare |
| **Factor Analysis FF5** | ❌ da fare |

---

## 🎯 Obiettivi Roadmap Espansione

### v16.0.0 — Feature Differenzianti (feb–apr 2027, ~10 settimane)

```
[OB-1] Telegram Bot Integration (Notifiche mobili)
[OB-2] Options Chain Analytics (yfinance già supporta)
[OB-3] Alternative Data Sources (Google Trends, Reddit, Wikipedia)
[OB-4] Multi-Broker Import (Degiro, Fineco, Trading212 CSV)
[OB-5] PDF Report Automatico Settimanale
[OPT-1] COT Report CFTC (Commitment of Traders)
[OPT-2] Factor Analysis Fama-French 5 Fattori
```

### v17.0.0 — Terminale Istituzionale (mag–dic 2027, ~15 settimane)

```
[OB-1] LLM Locale Ollama/FinGPT (RAG su bilanci + earnings call)
[OB-2] Portfolio Optimizer Avanzato (Black-Litterman, HRP, Min-CVaR)
[OB-3] Risk Management Istituzionale (Kelly, Factor Decomposition, LVaR)
[OB-4] Regime-Conditional Allocation (HMM → CVaR Optimizer)
[OB-5] Event Study Engine (Abnormal Returns, CAR)
[OPT-1] Chronos Foundation Model (zero-shot TS forecasting)
[OPT-2] Geopolitical Risk Index (GDELT + GPR)
[OPT-3] Tax-Loss Harvesting Automatico (suggerimenti fiscali IT)
```

---

## 📅 v16.0.0 — SESSIONE 1: Telegram Bot (1–2h)

**Obiettivo:** Notifiche push su smartphone per tutti gli alert MarketAI

**File da creare:**
```
shared/
  telegram_notifier.py      ← TelegramNotifier singleton
  notification_types.py     ← dataclass per ogni tipo di notifica

config/
  telegram_config.yaml      ← tipi alert abilitati, soglie

tests/shared/
  test_telegram_notifier.py
```

**telegram_notifier.py:**
```python
# shared/telegram_notifier.py
"""TelegramNotifier: notifiche push via Bot API Telegram.

Setup:
  1. Creare bot con @BotFather → ottieni TELEGRAM_BOT_TOKEN
  2. Inviare un messaggio al bot → ottenere TELEGRAM_CHAT_ID
  3. Aggiungere entrambi in .env

Non richiede server: usa Telegram Bot API (polling o webhook).
Gratuito illimitato per uso personale.

.env:
  TELEGRAM_BOT_TOKEN=1234567890:ABCdef...
  TELEGRAM_CHAT_ID=123456789
  TELEGRAM_ALERTS_ENABLED=true
"""
from __future__ import annotations
import os
import asyncio
from dataclasses import dataclass
from enum import Enum
from typing import Optional
import aiohttp  # già in stack
import structlog

log = structlog.get_logger(__name__)

class AlertLevel(str, Enum):
    INFO    = "ℹ️"
    WARNING = "⚠️"
    CRITICAL = "🚨"
    SUCCESS = "✅"

@dataclass
class TelegramAlert:
    level: AlertLevel
    title: str
    message: str
    data: Optional[dict] = None

class TelegramNotifier:
    """Singleton per invio notifiche via Telegram Bot API."""
    _instance: Optional["TelegramNotifier"] = None

    def __init__(self) -> None:
        self._token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        self._chat_id = os.getenv("TELEGRAM_CHAT_ID", "")
        self._enabled = os.getenv("TELEGRAM_ALERTS_ENABLED", "false").lower() == "true"
        self._base_url = f"https://api.telegram.org/bot{self._token}"

    @classmethod
    def get_instance(cls) -> "TelegramNotifier":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    async def send(self, alert: TelegramAlert) -> bool:
        """Invia notifica. Ritorna True se successo."""
        if not self._enabled or not self._token or not self._chat_id:
            log.debug("telegram.disabled_or_not_configured")
            return False
        text = f"{alert.level.value} *{alert.title}*\n\n{alert.message}"
        if alert.data:
            for k, v in alert.data.items():
                text += f"\n• {k}: `{v}`"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self._base_url}/sendMessage",
                    json={"chat_id": self._chat_id, "text": text, "parse_mode": "Markdown"},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    ok = resp.status == 200
                    if not ok:
                        log.warning("telegram.send_failed", status=resp.status)
                    return ok
        except Exception as e:
            log.error("telegram.error", error=str(e))
            return False

    def send_sync(self, alert: TelegramAlert) -> bool:
        """Wrapper sincrono per uso da APScheduler."""
        return asyncio.run(self.send(alert))
```

**Alert types da integrare:**
```python
# Esempi di alert pre-configurati

# In shared/alerts/vix_alert.py
async def check_vix_alert(vix: float) -> None:
    if vix > 30:
        await TelegramNotifier.get_instance().send(TelegramAlert(
            level=AlertLevel.CRITICAL,
            title="VIX in zona stress",
            message=f"VIX ha raggiunto {vix:.1f} — mercato in stress elevato.",
            data={"VIX": f"{vix:.1f}", "Regime atteso": "STRESS"},
        ))

# In shared/alerts/portfolio_alert.py
async def check_portfolio_drawdown(pct_change: float) -> None:
    if pct_change < -0.05:
        await TelegramNotifier.get_instance().send(TelegramAlert(
            level=AlertLevel.WARNING,
            title="Portafoglio in calo",
            message=f"Il portafoglio ha perso il {abs(pct_change):.1%} nelle ultime 24h.",
        ))

# In engine/analytics/evaluation/drift_detector.py (già esiste)
# Quando drift level = CRITICAL:
await TelegramNotifier.get_instance().send(TelegramAlert(
    level=AlertLevel.WARNING,
    title="Drift modello rilevato",
    message=f"{model_name} su {symbol}: MAE +{degradation:.0%} vs baseline.",
))
```

**Comandi bot (risposta a messaggi in arrivo):**
```python
# shared/telegram_bot_handler.py
# Polling ogni 30s in background thread
COMMANDS = {
    "/status": lambda: health_check_summary(),
    "/portfolio": lambda: net_worth_summary(),
    "/vix": lambda: vix_current_with_regime(),
    "/regime": lambda: market_regime_summary(),
    "/help": lambda: list_commands(),
}
```

**Definition of Done — Sessione 1:**
```
□ TelegramNotifier: send() funzionante (test con bot reale)
□ Alert VIX > 30: notifica arriva su smartphone
□ Alert portafoglio -5%: notifica arriva
□ Alert drift modello: integrato in DriftDetector
□ Comandi /status e /portfolio funzionanti
□ TELEGRAM_ALERTS_ENABLED=false default (sicuro senza configurazione)
□ pytest -m regression: 0 failed
□ .env.example aggiornato con variabili Telegram
```

---

## 📅 v16.0.0 — SESSIONE 2: Options Chain Analytics (1–2h)

**Obiettivo:** Analisi completa del mercato opzioni via yfinance

**File da creare:**
```
engine/market_data/options/
  __init__.py
  options_fetcher.py       ← fetch chain completa via yfinance
  greeks_calculator.py     ← Delta, Gamma, Theta, Vega, Rho (Black-Scholes)
  options_metrics.py       ← Put/Call ratio, Max Pain, IV percentile

presentation/dashboard_engine/pages/
  O1_Options_Chain.py      ← tabella chain interattiva
  O2_Volatility_Surface.py ← superficie IV 3D
```

**options_fetcher.py:**
```python
# engine/market_data/options/options_fetcher.py
"""Fetch catena opzioni via yfinance.

yfinance già supporta opzioni: ticker.options → scadenze disponibili
                                ticker.option_chain(date) → calls + puts DataFrame

Pipeline: fetch → clean → validate (Pandera) → cache (diskcache TTL=900s)
Regola 12: Mai fetch nelle funzioni di lettura.
"""
from __future__ import annotations
from dataclasses import dataclass
import pandas as pd
import yfinance as yf
from shared.resilience.error_policy import apply_error_policy

@dataclass
class OptionsSnapshot:
    ticker: str
    expiration: str
    calls: pd.DataFrame      # strike, bid, ask, volume, openInterest, impliedVolatility
    puts: pd.DataFrame
    underlying_price: float
    put_call_ratio: float
    max_pain: float

class OptionsFetcher:
    """Fetcher per catene opzioni. Usa ProviderRegistry come fallback."""

    @apply_error_policy(level="RECOVER", fallback=None, context="options_fetcher.fetch")
    def fetch_chain(self, ticker: str, expiration: str | None = None) -> OptionsSnapshot | None:
        yf_ticker = yf.Ticker(ticker)
        dates = yf_ticker.options
        if not dates:
            return None
        exp = expiration or dates[0]
        chain = yf_ticker.option_chain(exp)
        info = yf_ticker.fast_info
        price = float(info.last_price)
        pcr = self._put_call_ratio(chain.calls, chain.puts)
        max_pain = self._max_pain(chain.calls, chain.puts)
        return OptionsSnapshot(
            ticker=ticker, expiration=exp,
            calls=chain.calls, puts=chain.puts,
            underlying_price=price,
            put_call_ratio=pcr, max_pain=max_pain,
        )

    def _put_call_ratio(self, calls: pd.DataFrame, puts: pd.DataFrame) -> float:
        call_vol = calls["volume"].fillna(0).sum()
        put_vol = puts["volume"].fillna(0).sum()
        return float(put_vol / (call_vol + 1e-8))

    def _max_pain(self, calls: pd.DataFrame, puts: pd.DataFrame) -> float:
        """Calcola Max Pain: prezzo a cui il valore totale delle opzioni è minimo."""
        strikes = sorted(set(calls["strike"].tolist() + puts["strike"].tolist()))
        pain = {}
        for s in strikes:
            call_pain = calls[calls["strike"] > s]["openInterest"].fillna(0).sum() * (
                calls[calls["strike"] > s]["strike"] - s).sum()
            put_pain = puts[puts["strike"] < s]["openInterest"].fillna(0).sum() * (
                s - puts[puts["strike"] < s]["strike"]).sum()
            pain[s] = call_pain + put_pain
        return float(min(pain, key=pain.get)) if pain else 0.0
```

**greeks_calculator.py (Black-Scholes):**
```python
# engine/market_data/options/greeks_calculator.py
"""Calcolo Greeks con Black-Scholes. Usa scipy già in stack."""
import numpy as np
from scipy.stats import norm

def delta(S, K, T, r, sigma, option_type="call") -> float:
    """Delta: sensibilità prezzo opzione a variazione spot."""
    d1 = (np.log(S/K) + (r + 0.5*sigma**2)*T) / (sigma*np.sqrt(T))
    if option_type == "call":
        return float(norm.cdf(d1))
    return float(norm.cdf(d1) - 1)

def gamma(S, K, T, r, sigma) -> float:
    """Gamma: tasso di variazione del Delta."""
    d1 = (np.log(S/K) + (r + 0.5*sigma**2)*T) / (sigma*np.sqrt(T))
    return float(norm.pdf(d1) / (S * sigma * np.sqrt(T)))

def theta(S, K, T, r, sigma, option_type="call") -> float:
    """Theta: decadimento temporale (per giorno)."""
    d1 = (np.log(S/K) + (r + 0.5*sigma**2)*T) / (sigma*np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    if option_type == "call":
        t = (-S*norm.pdf(d1)*sigma/(2*np.sqrt(T)) - r*K*np.exp(-r*T)*norm.cdf(d2))
    else:
        t = (-S*norm.pdf(d1)*sigma/(2*np.sqrt(T)) + r*K*np.exp(-r*T)*norm.cdf(-d2))
    return float(t / 365)

def vega(S, K, T, r, sigma) -> float:
    """Vega: sensibilità alla volatilità implicita (per 1%)."""
    d1 = (np.log(S/K) + (r + 0.5*sigma**2)*T) / (sigma*np.sqrt(T))
    return float(S * norm.pdf(d1) * np.sqrt(T) * 0.01)
```

**Definition of Done — Sessione 2:**
```
□ OptionsFetcher.fetch_chain(): dati reali AAPL options
□ Put/Call ratio calcolato correttamente
□ Max Pain calcolato e visualizzato
□ Greeks: Delta/Gamma/Theta/Vega su tutte le righe della chain
□ O1_Options_Chain: tabella interattiva filtrabile per strike/scadenza
□ O2_Volatility_Surface: grafico 3D IV per strike × scadenza
□ Dati cachati 15 minuti (options non cambiano a ogni tick)
□ pytest -m regression: 0 failed
```

---

## 📅 v16.0.0 — SESSIONE 3: Alternative Data Sources (1–2h)

**Obiettivo:** Dati non-standard che Bloomberg vende a $50k/anno

**File da creare:**
```
engine/market_data/alternative/
  __init__.py
  google_trends_fetcher.py   ← pytrends (interesse retail)
  reddit_sentiment.py        ← PRAW (WSB, r/investing)
  wikipedia_views.py         ← Wikimedia API (pageviews)
  alt_data_aggregator.py     ← AltDataScore composito [0,1]
```

**google_trends_fetcher.py:**
```python
# engine/market_data/alternative/google_trends_fetcher.py
"""Google Trends: proxy per interesse retail su un asset.

Letteratura: Da et al. (2011) — ricerche Google anticipano rendimenti.
Studio: aumento >2σ ricerche → ritorni anomali a 2 settimane.

Nota: pytrends non ha rate limit esplicito ma richiede sleep tra richieste.
Rate limit config: config/rate_limits.yaml → google_trends: 10/min
"""
from __future__ import annotations
from pathlib import Path
import pandas as pd
import structlog

log = structlog.get_logger(__name__)

class GoogleTrendsFetcher:
    """Fetch interesse Google per ticker/keyword su finestra temporale."""

    def fetch(self, keyword: str, timeframe: str = "today 12-m") -> pd.DataFrame:
        """
        Fetch trend normalizzato [0, 100] per keyword.
        Args:
            keyword: es. "Apple stock", "Bitcoin", "NVDA"
            timeframe: "today 3-m", "today 12-m", "today 5-y"
        Returns:
            DataFrame con colonne: date, interest (0-100), keyword
        """
        try:
            from pytrends.request import TrendReq
        except ImportError:
            log.error("google_trends.pytrends_missing")
            return pd.DataFrame()
        pytrend = TrendReq(hl="en-US", tz=0)
        pytrend.build_payload([keyword], timeframe=timeframe, geo="")
        df = pytrend.interest_over_time()
        if df.empty:
            return pd.DataFrame()
        df = df.reset_index()[["date", keyword]].rename(columns={keyword: "interest"})
        df["keyword"] = keyword
        df["date"] = pd.to_datetime(df["date"], utc=True)
        return df
```

**alt_data_aggregator.py:**
```python
# engine/market_data/alternative/alt_data_aggregator.py
"""AltDataScore: score composito [0,1] da dati alternativi.

Score > 0.7 → segnale bullish retail
Score < 0.3 → segnale bearish / disinteresse retail
Score 0.3-0.7 → neutro

Componenti:
  · Google Trends (peso 40%): interesse di ricerca normalizzato
  · Reddit Mention Score (peso 35%): menzioni + sentiment WSB/investing
  · Wikipedia Views (peso 25%): pageviews settimana vs media 90gg
"""
from dataclasses import dataclass
import numpy as np

@dataclass
class AltDataScore:
    ticker: str
    composite_score: float       # [0, 1]
    google_trends_score: float
    reddit_score: float
    wikipedia_score: float
    signal: str                  # "BULLISH_RETAIL" | "NEUTRAL" | "BEARISH_RETAIL"
    note: str

class AltDataAggregator:
    WEIGHTS = {"google": 0.40, "reddit": 0.35, "wikipedia": 0.25}

    def score(self, ticker: str, company_name: str) -> AltDataScore:
        g = self._google_score(company_name)
        r = self._reddit_score(ticker)
        w = self._wikipedia_score(company_name)
        composite = (
            self.WEIGHTS["google"] * g +
            self.WEIGHTS["reddit"] * r +
            self.WEIGHTS["wikipedia"] * w
        )
        if composite > 0.7:
            signal = "BULLISH_RETAIL"
            note = "Interesse retail elevato — potenziale momentum a breve"
        elif composite < 0.3:
            signal = "BEARISH_RETAIL"
            note = "Disinteresse retail — assenza di catalyst retail"
        else:
            signal = "NEUTRAL"
            note = "Interesse retail nella norma"
        return AltDataScore(ticker, composite, g, r, w, signal, note)
```

**Definition of Done — Sessione 3:**
```
□ GoogleTrendsFetcher: dati reali per "Apple stock" su 12 mesi
□ RedditSentiment: menzioni WSB per ticker populari (AAPL, NVDA, GME)
□ WikipediaViews: pageviews settimanali vs media storica
□ AltDataScore: composito [0,1] corretto su 3 ticker noti
□ Integrazione in E7_Sentiment.py: sezione "Alt Data" aggiunta
□ RateLimitManager: google_trends in config/rate_limits.yaml
□ pytest -m regression: 0 failed
□ Feature flag: alt_data_sources: false (default, heavy API calls)
```

---

## 📅 v16.0.0 — SESSIONE 4: Multi-Broker Import (1–2h)

**Obiettivo:** Import posizioni da Degiro, Fineco, Trading212 oltre eToro

**File da creare:**
```
personal/portfolio/importers/
  __init__.py
  base_importer.py        ← BrokerImporter ABC
  degiro_importer.py      ← parser CSV Degiro
  fineco_importer.py      ← parser CSV/PDF Fineco
  trading212_importer.py  ← parser CSV Trading212
  importer_registry.py    ← auto-detect formato da header CSV
```

**base_importer.py:**
```python
# personal/portfolio/importers/base_importer.py
"""BrokerImporter ABC: interfaccia comune per tutti i broker.

Ogni importer:
  1. Legge il file CSV/XLSX del broker
  2. Normalizza le colonne nel formato Position standard
  3. Valida con Pandera (schema PositionSchema)
  4. Ritorna lista Position da salvare su SQLite

Formato Position comune:
  ticker: str          (es. "AAPL", "SWDA.L")
  quantity: float
  avg_cost: float      (prezzo medio acquisto in valuta base)
  currency: Currency
  broker: str          (es. "degiro", "etoro", "fineco")
  asset_class: str     (es. "equity", "etf", "bond")
  open_date: datetime
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from pathlib import Path
import pandas as pd
from shared.types import Currency

class BrokerImporter(ABC):
    """Interfaccia comune per import da broker."""

    @property
    @abstractmethod
    def broker_name(self) -> str: ...

    @abstractmethod
    def can_import(self, file_path: Path) -> bool:
        """True se il file è del formato corretto per questo broker."""
        ...

    @abstractmethod
    def import_file(self, file_path: Path) -> pd.DataFrame:
        """
        Legge file broker → DataFrame normalizzato.
        Colonne obbligatorie: ticker, quantity, avg_cost, currency, broker, asset_class
        """
        ...

    def _normalize_ticker(self, raw: str, exchange: str = "") -> str:
        """Normalizza ticker al formato standard (es. "VWCE.DE" non "VWCE")."""
        ...
```

**degiro_importer.py (formato CSV Degiro):**
```python
# personal/portfolio/importers/degiro_importer.py
"""Degiro CSV importer.

Degiro esporta CSV con colonne (italiano):
  Prodotto, Codice ISIN, Simbolo, Borsa, Quantità, Prezzo chiusura, Valore locale, Valore in EUR
"""
DEGIRO_COLUMNS = {
    "Prodotto": "name", "Simbolo": "raw_ticker",
    "Borsa": "exchange", "Quantità": "quantity",
    "Prezzo chiusura": "close_price", "Valore in EUR": "value_eur"
}

EXCHANGE_SUFFIX = {
    "XETRA": ".DE", "EURONEXT": ".PA", "BORSA ITALIANA": ".MI",
    "LSE": ".L", "NASDAQ": "", "NYSE": "",
}
```

**importer_registry.py:**
```python
class ImporterRegistry:
    """Auto-detect broker dal file CSV caricato."""
    _importers = [DeGiroImporter(), FinecoImporter(), Trading212Importer(), EToroImporter()]

    @classmethod
    def detect_and_import(cls, file_path: Path) -> pd.DataFrame:
        for importer in cls._importers:
            if importer.can_import(file_path):
                return importer.import_file(file_path)
        raise ValueError(f"Formato broker non riconosciuto: {file_path.name}")
```

**Definition of Done — Sessione 4:**
```
□ DeGiroImporter: import CSV reale con ticker normalizzati
□ FinecoImporter: import CSV (formato italiano, virgola decimale)
□ Trading212Importer: import CSV con conversione valuta
□ ImporterRegistry: auto-detect su 4 broker
□ P2_Portafoglio_eToro.py: rinominato P2_Portfolio.py, multi-broker
□ Aggregazione multi-broker in P1_Overview_Patrimonio
□ pytest -m regression: 0 failed
```

---

## 📅 v16.0.0 — SESSIONE 5: PDF Report Automatico (1–2h)

**Obiettivo:** Report PDF settimanale professionale, inviato via Telegram

**File da creare:**
```
presentation/reports/
  __init__.py
  report_builder.py        ← orchestratore report
  templates/
    weekly_report.html     ← Jinja2 template
    monthly_report.html
  sections/
    market_overview.py     ← sezione mercati
    portfolio_section.py   ← sezione portafoglio
    macro_section.py       ← sezione macro
    forecast_section.py    ← sezione previsioni
    personal_section.py    ← sezione finanza personale

scripts/
  generate_report.py       ← entry point manuale/scheduler
```

**report_builder.py:**
```python
# presentation/reports/report_builder.py
"""Report PDF settimanale stile investment bank.

Stack: Jinja2 (template HTML) → WeasyPrint (HTML→PDF)
Entrambi già in pyproject.toml.

Struttura report:
  1. Cover page (data, firma)
  2. Executive Summary (LLM se abilitato, altrimenti KPI key)
  3. Market Overview (heatmap asset, regime corrente)
  4. Portfolio Analysis (performance, attribuzione, rischio)
  5. Macro Dashboard (FRED indicators semaforo)
  6. Forecasts (ensemble 30gg, scenari)
  7. Personal Finance (obiettivi, cashflow, net worth)
  8. Tax Summary (YTD, plus/minusvalenze)

Automazione: APScheduler → ogni domenica 08:00
             → genera PDF → invia via Telegram
"""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
import structlog

log = structlog.get_logger(__name__)

TEMPLATES_DIR = Path(__file__).parent / "templates"
REPORTS_DIR = Path("reports")

class ReportBuilder:
    def __init__(self) -> None:
        self._env = Environment(loader=FileSystemLoader(TEMPLATES_DIR))
        REPORTS_DIR.mkdir(exist_ok=True)

    def build_weekly(self) -> Path:
        """Genera report settimanale. Ritorna path del PDF."""
        data = self._collect_data()
        template = self._env.get_template("weekly_report.html")
        html = template.render(**data, generated_at=datetime.utcnow())
        output_path = REPORTS_DIR / f"MarketAI_Weekly_{datetime.now():%Y%m%d}.pdf"
        self._html_to_pdf(html, output_path)
        log.info("report.generated", path=str(output_path))
        return output_path

    def _collect_data(self) -> dict:
        """Raccoglie tutti i dati per il report. Non fa fetch diretti."""
        # Legge da DuckDB/SQLite (già aggiornati dallo scheduler)
        return {
            "market": self._market_section(),
            "portfolio": self._portfolio_section(),
            "macro": self._macro_section(),
        }

    def _html_to_pdf(self, html: str, output: Path) -> None:
        from weasyprint import HTML
        HTML(string=html).write_pdf(str(output))
```

**Integrazione Telegram:**
```python
# APScheduler job in scripts/run_scheduler.py
@scheduler.scheduled_job("cron", day_of_week="sun", hour=8, minute=0)
def weekly_report_job():
    builder = ReportBuilder()
    pdf_path = builder.build_weekly()
    # Invia PDF via Telegram
    notifier = TelegramNotifier.get_instance()
    notifier.send_document_sync(pdf_path, caption="📊 MarketAI Report Settimanale")
```

**Definition of Done — Sessione 5:**
```
□ ReportBuilder.build_weekly(): PDF generato senza errori
□ Template HTML: struttura professionale con Jinja2
□ Sezioni: market, portfolio, macro (personal se dati disponibili)
□ PDF inviato via Telegram (se configurato)
□ Scheduler: job domenica 08:00 registrato
□ Manuale: `poetry run python scripts/generate_report.py`
□ pytest -m regression: 0 failed
```

---

## 📅 v16.0.0 — SESSIONE 6: Factor Analysis Fama-French (1–2h)

**Obiettivo:** Decomposizione rendimenti per fattori (stile Barra/Axioma)

**File da creare:**
```
engine/analytics/
  factor_analysis/
    __init__.py
    ff_fetcher.py          ← download fattori FF5 da Kenneth French
    factor_model.py        ← regressione OLS rendimenti su fattori
    portfolio_exposure.py  ← exposure fattori portafoglio eToro

presentation/dashboard_engine/pages/
  Q_Factor_Analysis.py     ← NUOVA pagina
```

**ff_fetcher.py:**
```python
# engine/analytics/factor_analysis/ff_fetcher.py
"""Fetch fattori Fama-French 5 da Kenneth French Data Library.

URL: https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html
Fonte alternativa: pandas-datareader (già in stack)

Fattori FF5:
  MKT-RF  → Market excess return (CAPM)
  SMB     → Small Minus Big (size factor)
  HML     → High Minus Low (value factor)
  RMW     → Robust Minus Weak (profitability)
  CMA     → Conservative Minus Aggressive (investment)
  RF      → Risk-Free rate (T-bill)
"""
import pandas_datareader.data as web
import pandas as pd

class FFFactorFetcher:
    def fetch_ff5_daily(self, start: str, end: str) -> pd.DataFrame:
        """Fetch fattori Fama-French 5 daily. Gratuito, da French's website."""
        df = web.DataReader(
            "F-F_Research_Data_5_Factors_2x3_daily",
            "famafrench",
            start=start,
            end=end,
        )[0]
        df.columns = ["MKT_RF", "SMB", "HML", "RMW", "CMA", "RF"]
        return df / 100  # converti da % a decimale
```

**factor_model.py:**
```python
class FactorModel:
    """Regressione OLS rendimenti portafoglio su fattori FF5."""

    def fit(self, returns: pd.Series, factors: pd.DataFrame) -> "FactorModel":
        """
        Stima alpha e beta per ogni fattore.
        Alpha positivo e statisticamente significativo → rendimento anomalo
                                                          non spiegato dai fattori.
        """
        import statsmodels.api as sm
        X = sm.add_constant(factors)
        y = returns - factors["RF"]  # excess returns
        self._result = sm.OLS(y, X).fit()
        return self

    @property
    def alpha(self) -> float:
        return float(self._result.params["const"])

    @property
    def alpha_tstat(self) -> float:
        return float(self._result.tvalues["const"])

    @property
    def r_squared(self) -> float:
        return float(self._result.rsquared)

    @property
    def factor_exposures(self) -> dict[str, float]:
        return {k: float(v) for k, v in self._result.params.items() if k != "const"}
```

**Definition of Done — Sessione 6:**
```
□ FFFactorFetcher: dati FF5 daily dal 2000 a oggi
□ FactorModel: alpha e beta per portafoglio reale eToro
□ Q_Factor_Analysis: tabella esposizioni + alpha con t-stat
□ Interpretazione: "Il tuo portafoglio ha alpha di X% annuo (t-stat: Y)"
□ pytest -m regression: 0 failed
□ Dati FF5 persistiti su DuckDB (migration 008)
```

---

## 📅 v17.0.0 — SESSIONE 1: LLM Locale Ollama + RAG (2h)

**Obiettivo:** Analista AI che risponde a domande su bilanci e earning call

**Prerequisito hardware: RAM 32GB (upgrade necessario)**

**File da creare:**
```
engine/ai/
  __init__.py
  llm_client.py            ← wrapper Ollama HTTP API
  rag_engine.py            ← RAG con ChromaDB o LanceDB
  document_ingester.py     ← ingestione PDF bilanci, earnings transcript
  analyst_agent.py         ← agente conversazionale finance

presentation/dashboard_engine/pages/
  AI1_Analyst.py           ← chat interface
```

**llm_client.py:**
```python
# engine/ai/llm_client.py
"""Ollama HTTP client per inferenza LLM locale.

Modelli raccomandati per hardware con 32GB RAM:
  mistral:7b        → 8GB RAM inferenza, qualità generale alta
  phi3:mini         → 4GB RAM, più veloce, qualità inferiore
  llama3.2:3b       → 4GB RAM, bilanciato
  (con RTX 4060 8GB) → mistral:7b-q4 su GPU → 5GB VRAM, molto veloce

Feature flag: ollama_narrative (config/feature_flags.yaml)
Verifica prerequisito RAM: require_ram(min_gb=8.0, context="Ollama LLM")
"""
from __future__ import annotations
import aiohttp
from shared.feature_flags import require_enabled
from engine.analytics.forecasting.nbeats.ram_check import require_ram

class OllamaClient:
    """Client HTTP per Ollama. Non richiede dipendenza Python aggiuntiva."""
    BASE_URL = "http://localhost:11434"

    async def generate(self, prompt: str, model: str = "mistral:7b") -> str:
        require_enabled("ollama_narrative")
        require_ram(min_gb=6.0, context="Ollama inference")
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.BASE_URL}/api/generate",
                json={"model": model, "prompt": prompt, "stream": False},
                timeout=aiohttp.ClientTimeout(total=120),
            ) as resp:
                data = await resp.json()
                return data.get("response", "")
```

**rag_engine.py:**
```python
# engine/ai/rag_engine.py
"""RAG Engine: Retrieval Augmented Generation su documenti personali.

Supporta:
  · PDF bilanci aziendali (10-K, annual report)
  · Earnings call transcripts (testo grezzo)
  · Note personali (Obsidian vault markdown)

Processo:
  1. Document ingestion → chunk 512 token
  2. Embedding con sentence-transformers (no GPU necessario)
  3. Storage vettori: ChromaDB locale (SQLite-backed)
  4. Query: top-K chunk rilevanti → prompt → Ollama

Nota: sentence-transformers/all-MiniLM-L6-v2 → ~80MB, CPU-friendly
"""
```

**Definition of Done — Sessione 1 v17:**
```
□ OllamaClient: generate() funzionante (mistral:7b installato)
□ DocumentIngester: ingestione PDF bilancio NVDA 10-K
□ RAGEngine: risposta a "Qual è il margine operativo di NVDA nel 2024?"
□ AI1_Analyst.py: chat interface in Streamlit
□ Feature flag: ollama_narrative: false (default)
□ RAM check: blocca se <6GB disponibili
□ pytest -m regression: 0 failed
```

---

## 📅 v17.0.0 — SESSIONE 2: Portfolio Optimizer Black-Litterman + HRP (2h)

**Obiettivo:** Ottimizzazione portafoglio avanzata oltre Mean-Variance

**File da modificare/creare:**
```
personal/allocator/
  black_litterman.py       ← BL model con view personali
  hrp_optimizer.py         ← Hierarchical Risk Parity
  min_cvar_optimizer.py    ← Minimum CVaR via cvxpy
  optimizer_factory.py     ← scelta algoritmo via config
```

**black_litterman.py:**
```python
# personal/allocator/black_litterman.py
"""Black-Litterman Portfolio Optimization.

Combina:
  · Market equilibrium (implied returns da CAPM)
  · View personali dell'investitore (con confidence level)

Esempio view:
  "Credo che NVDA sovraperformerà SPY del 10% nei prossimi 6 mesi"
  → tau * omega → BL posterior expected returns
  → cvxpy Max Sharpe optimization

Richiede: cvxpy (già in stack), numpy, scipy
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass

@dataclass
class InvestorView:
    """View personale su un asset o pair."""
    assets: list[str]           # ["NVDA"] o ["NVDA", "SPY"] per pair
    expected_return: float      # es. 0.10 = 10%
    confidence: float           # [0, 1] — quanto sei sicuro

class BlackLittermanOptimizer:
    """BL optimizer che bilancia equilibrio mercato e view personali."""
    def __init__(self, risk_aversion: float = 2.5, tau: float = 0.05) -> None:
        self._lambda = risk_aversion
        self._tau = tau

    def optimize(
        self,
        returns: pd.DataFrame,
        market_caps: pd.Series,
        views: list[InvestorView],
    ) -> pd.Series:
        """
        Calcola pesi ottimali BL.
        Returns: pd.Series con pesi per ogni asset.
        """
        # 1. Implied equilibrium returns (CAPM)
        sigma = returns.cov()
        w_mkt = market_caps / market_caps.sum()
        pi = self._lambda * sigma @ w_mkt

        # 2. P matrix (view portfolio), Q vector (expected excess returns)
        P, Q, Omega = self._build_views_matrices(views, returns.columns, sigma)

        # 3. BL posterior returns
        tau_sigma = self._tau * sigma
        M = np.linalg.inv(np.linalg.inv(tau_sigma) + P.T @ np.linalg.inv(Omega) @ P)
        mu_bl = M @ (np.linalg.inv(tau_sigma) @ pi + P.T @ np.linalg.inv(Omega) @ Q)

        # 4. Max Sharpe con cvxpy
        import cvxpy as cp
        w = cp.Variable(len(returns.columns))
        ret = mu_bl @ w
        risk = cp.quad_form(w, sigma.values)
        prob = cp.Problem(cp.Maximize(ret - self._lambda * risk),
                          [cp.sum(w) == 1, w >= 0])
        prob.solve(solver=cp.CLARABEL)
        return pd.Series(w.value, index=returns.columns)
```

**Definition of Done — Sessione 2 v17:**
```
□ BlackLitterman: pesi con 3 view di test convergono correttamente
□ HRPOptimizer: clustering asset, pesi non-negativi, somma=1
□ MinCVaROptimizer: CVaR minimizzato su dati storici
□ OptimizerFactory: selezione via config/feature_flags.yaml
□ P6_Profilo_Investitore: sezione "Allocazione Ottimale" aggiornata
□ pytest -m regression: 0 failed
```

---

## 📅 v17.0.0 — SESSIONI 3-6: Risk, Regime Allocation, Event Study (sintesi)

**SESSIONE 3: Risk Management Istituzionale**
```
File da creare:
  engine/analytics/risk/
    kelly_calculator.py      ← Kelly Criterion + Fractional Kelly
    factor_decomposition.py  ← attribuzione rischio per fattore FF5
    liquidity_var.py         ← LVaR = VaR + liquidity premium
    tail_risk_metrics.py     ← ES, Omega ratio, modified VaR Cornish-Fisher

Definition of Done:
□ KellyCriterion: full e fractional (0.25x, 0.5x) funzionanti
□ FactorDecomposition: % rischio da ogni fattore FF5
□ LVaR: calcolato per ogni posizione eToro
□ Pagina Q_Risk_Dashboard aggiornata con breakdown istituzionale
```

**SESSIONE 4: Regime-Conditional Allocation**
```
File da creare:
  engine/analytics/
    regime_allocator.py    ← HMM regime → parametri ottimali → cvxpy

Logic:
  Regime BULL    → max Sharpe con target return 8%
  Regime BEAR    → min CVaR con max drawdown 10%
  Regime STRESS  → min variance (cash-heavy)
  Regime TRANSITION → equally-weighted conservative

Definition of Done:
□ Per ogni regime: pesi ottimali calcolati con cvxpy
□ Backtest regime-conditional vs static 60/40: 10 anni AAPL/SPY/TLT
□ Visualizzazione in Q_Regime_Allocation (NUOVA pagina)
```

**SESSIONE 5: Event Study Engine**
```
File da creare:
  engine/analytics/
    event_study/
      abnormal_returns.py  ← AR = actual - expected (market model)
      car_calculator.py    ← CAR su finestre [-N, +N]
      event_catalog.py     ← earnings, FOMC, CPI, M&A

Events supportati:
  · Earnings announcement → AR su [-1, +5] giorni
  · FOMC meeting → AR su [0, +3] giorni
  · CPI release → AR su [0, +1] giorni

Definition of Done:
□ AbnormalReturns: market model corretto (OLS su estimation window)
□ CAR: statisticamente testato (t-test)
□ Visualizzazione in E6_Macro: "Event Study" tab
```

**SESSIONE 6: Validazione Finale v17 + CLAUDE.md v3**
```
Attività:
  □ Test hardware su tutte le nuove feature
  □ CLAUDE.md v3 aggiornato:
    - Sezione "AI Layer" (Ollama, RAG)
    - Sezione "Options Analytics"
    - Sezione "Alternative Data"
    - Sezione "Advanced Portfolio"
  □ Home.md vault aggiornato con tutte le nuove pagine
  □ PDF Report: validazione visiva
  □ pytest --cov --cov-fail-under=89: verde
  □ Tutti i feature flag documentati
```

---

## 🖥️ HARDWARE UPGRADE PATH

### Stato Attuale e Limiti

| Componente | Spec | Limite principale |
|------------|------|-------------------|
| CPU | Ryzen 5 5600 (6C/12T) | Training DL lento (~5min N-BEATS) |
| GPU | RX 6700 8GB | ROCm instabile → inutilizzabile per DL |
| RAM | 16GB DDR4 3200 | **LLM >7B impossibile, training pesante lento** |
| SSD | 512GB NVMe | Sufficiente per 2-3 anni |

### Upgrade Prioritizzati

```
UPGRADE A — RAM 16GB → 32GB (IMMEDIATO, ~80 EUR)
Sblocca:
  ✅ Ollama + mistral:7b (8GB RAM inferenza)
  ✅ Sessioni v17 AI layer completamente funzionanti
  ✅ Training PatchTST su dataset medi
  ✅ DuckDB cache più grande in RAM
  ✅ Più processi simultanei (FastAPI + Streamlit + LLM)
Priorità: MASSIMA — fare PRIMA di iniziare v17

UPGRADE B — GPU NVIDIA RTX 4060 8GB (~300 EUR, entro 6-12 mesi)
Sblocca:
  ✅ N-BEATS training 10x più veloce (CPU ~5min → GPU ~30sec)
  ✅ LLM quantizzati su GPU: mistral:7b-q4 in ~5GB VRAM
  ✅ LSTM/GRU training stabile e veloce
  ✅ Chronos inference accelerata
  ✅ Anomaly Detection LSTM su dataset grandi
Priorità: ALTA se uso DL intensivo

UPGRADE C — RTX 4060 Ti 16GB (~500 EUR, 12-24 mesi)
Sblocca:
  ✅ mistral:7b in fp16 (14GB VRAM) senza quantizzazione
  ✅ FinGPT fine-tuning su dati personali
  ✅ Temporal Fusion Transformer completo
Priorità: MEDIA — solo se AI layer diventa centrale

COSTO TOTALE UPGRADE COMPLETO: ~880 EUR su 2 anni
CONFRONTO: Bloomberg Terminal = $24,000/anno
```

---

## 📊 TIMELINE COMPLETA 2026-2027

```
AGO–SET 2026      v11.0.0   Installer + Management UI (8 sessioni)
OTT 2026          v12.0.0   Provider System + CI/CD (5 sessioni)
NOV 2026          v13.0.0   Ensemble + FeatureBuilder (6 sessioni)
NOV–DIC 2026      v14.0.0   N-BEATS + FastAPI + Backtesting (7 sessioni)
DIC 2026–GEN 2027 v15.0.0   pywebview + Sessioni + Drift (7 sessioni)

─── UPGRADE RAM 32GB ─── (prerequisito v17)

FEB–APR 2027      v16.0.0   Feature Differenzianti (6 sessioni)
                             · Telegram Bot
                             · Options Chain
                             · Alt Data (GTrends, Reddit, Wikipedia)
                             · Multi-Broker Import
                             · PDF Report Automatico
                             · Factor Analysis FF5

─── UPGRADE GPU RTX 4060 (opzionale ma consigliato) ───

MAG–DIC 2027      v17.0.0   Terminale Istituzionale (6 sessioni)
                             · LLM locale + RAG
                             · Black-Litterman + HRP
                             · Risk Istituzionale (Kelly, LVaR)
                             · Regime-Conditional Allocation
                             · Event Study Engine

TOTALE: ~45 sessioni · ~24 mesi · Gennaio 2027 = MVP completo
```

---

## 📋 PIETRE MILIARI GO/NO-GO

| Milestone | Criterio GO | Hardware richiesto |
|-----------|-------------|-------------------|
| Fine v11 | Installer funzionante, Management UI, 0 regressioni | Attuale |
| Fine v12 | ProviderRegistry + CI verde | Attuale |
| Fine v13 | Ensemble + fan chart + coverage ≥ 89% | Attuale |
| Fine v14 | N-BEATS CPU < 3min, FastAPI /predict 200 OK | Attuale |
| Fine v15 | pywebview W11, MarketAI.exe < 80MB | Attuale |
| **Upgrade RAM** | **32GB installati e verificati** | ⚠️ ~80 EUR |
| Fine v16 | Telegram alerts funzionanti, Options chain, Alt data | 32GB RAM |
| Fine v17 | LLM risponde a domande bilancio, BL optimizer valido | 32GB RAM |

---

## 🧩 ANTI-PATTERN AGGIUNTIVI v16-v17

```
❌ LLM usato per calcoli quantitativi
   → LLM SOLO per narrativa/commento (Regola già in ROADMAP v6)

❌ Alternative data senza feature flag
   → alt_data_sources: false di default (API pesanti)

❌ Black-Litterman con view a confidence=1.0
   → max confidence 0.95, sempre tau > 0

❌ Options fetch senza cache (prezzi cambiano ogni tick)
   → diskcache TTL=900s per chain, TTL=60s per prezzi spot

❌ PDF report che chiama API esterne durante generazione
   → Dati già in DuckDB/SQLite — nessun fetch durante render

❌ Multi-broker import che sovrascrive posizioni esistenti
   → Merge intelligente con deduplication per ISIN

❌ Ollama avviato senza check RAM disponibile
   → require_ram(min_gb=6.0) SEMPRE prima di inferenza

❌ RAG su documenti non verificati (rischio hallucination)
   → Citare sempre la fonte (chunk specifico) nella risposta

❌ Kelly Criterion con stime di edge ottimistiche
   → Sempre usare Fractional Kelly (0.25x) come default conservativo

❌ Sessione Opus senza regression test iniziale
   → Obbligatorio: 0 failed prima di modificare qualsiasi file
```

---

*MarketAI Visione 2027 · Roadmap Espansione Post-v15*
*Pianificazione: Claude Sonnet 4.6 · Giugno 2026*
*Implementazione: Claude Code Pro (Opus 4.8)*
*Hardware attuale: Ryzen 5 5600 · RX 6700 · 16GB RAM*
*Hardware target: + 32GB RAM + RTX 4060 (consigliato)*
