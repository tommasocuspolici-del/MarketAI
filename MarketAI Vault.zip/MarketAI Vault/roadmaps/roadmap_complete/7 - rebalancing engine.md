# 🔴 ROADMAP — MarketAI v16.0.0 · Backtesting Pro + Smart Rebalancing Engine
> **v15.0.0 → v16.0.0** · Multi-Asset Backtesting · Portfolio Rebalancing Engine · Feature Audit  
> Prerequisito: v15.0.0 completato (pywebview UI · Persistenza Sessioni · Drift Detection)  
> Pianificazione: Claude Sonnet 4.6 · Implementazione: Claude Code Pro (Opus 4.8)  
> Sessioni: **9 sessioni** · Durata stimata: 1–2h ciascuna · Totale: ~6 settimane  
> Hardware: Ryzen 5 5600 · RX 6700 8GB (CPU-only) · 16GB RAM · 512GB NVMe · Windows 11

---

## 📋 ANALISI LACUNE — Partendo dal Vault v3.0

Prima di pianificare l'implementazione, questo documento mappa in modo onesto
**cosa manca**, **cosa non funziona** e **cosa esiste ma è inutilizzabile**.

### ❌ Lacune Critiche nel Backtesting

| Gap | Impatto | Presenza in vault |
|---|---|---|
| Nessun backtest **multi-asset / portfolio** | Alto — impossibile testare allocazioni reali | Assente |
| Nessuna strategia **regime-conditional** | Alto — stessa strategia in bull/bear è subottimale | Assente |
| Nessun backtest su **eventi macro** (FOMC, CPI) | Medio — event-driven trading non testabile | Assente |
| `Q12 Strategy Lab` senza spec di dettaglio | Alto — pagina esiste, funzionalità vaghe | Parziale |
| Walk-forward solo VectorBT, non integ. RealisticBacktester | Medio — costi realistici ignorati nel WF | Parziale |
| **Transaction-cost-aware** rebalancing backtest | Alto — manca la prova che ribilanciare valga i costi | Assente |
| Nessun test **factor-based** (Value, Momentum, Quality) | Medio — precludes confronto vs benchmark fattoriali | Assente |

### ❌ Lacune nel Portfolio Rebalancing Engine

| Gap | Impatto |
|---|---|
| Threshold statica (5%) — non si adatta al regime | Alto — in bear market si dovrebbe ribilanciare di meno |
| Nessuna stima costi vs benefici del ribilanciamento | Alto — il RebalancingAdvisor suggerisce trade senza confronto |
| Nessun **tax-aware rebalancing** (regime fiscale IT 26%) | Alto — per utenti italiani, ignorare le tax implica perdite reali |
| Nessuna gestione **azioni parziali** (eToro spesso frazionarie) | Medio — il calcolo dei trade non considera size minima |
| Nessun **drift monitoring nel tempo** (solo snapshot) | Medio — non si vede come il drift evolve settimana per settimana |
| Currency mismatch non gestita nel rebalancing (GBX/EUR/USD) | Medio — ribilanciamento cross-currency sbagliato |

### ⚠️ Feature Esistenti con Utilità Ridotta

| Feature | Problema | Decisione |
|---|---|---|
| **LSTM / GRU / CNN-LSTM / Transformer** (DL esistenti) | CPU-only → training 10+ min per serie, non usabile in pratica | **DEPRECARE** in produzione; lasciare come experimental |
| **N-BEATS** (v14) | Same problema GPU: CPU-only hidden_size=128 → ~3 min fit | Mantenere ma limitare a `lookback_window ≤ 30` su questo HW |
| **Ollama narrative** | Richiede installazione separata Ollama + modello — mai usata | **RIMUOVERE** dal codice attivo; lasciare solo in feature_flags |
| **SEC EDGAR bulk download** | Edgar per azioni italiane/europee → dati assenti; utile solo ETF USA | **LIMITARE** a watch-list configurabile, non bulk |
| **Transformer** (DL) | Su CPU: troppo lento per qualsiasi dataset reale | **DEPRECARE** in produzione — flag `transformer_model: false` permanente |
| **Granger Causality** in Correlation Engine | Richiede dataset con campioni > 1000, risultati difficili da interpretare | Mantenere ma nascondere in UI dietro "Advanced" toggle |

---

## 🎯 Obiettivi v16.0.0

### Obbligatori

```
[OB-1] Portfolio Backtesting Engine
        · PortfolioBacktester: backtest multi-asset con rebalancing periodico
        · Strategia: allocation + rebalancing ogni N periodi
        · Output: portfolio equity curve, contribution per asset, turnover
        · Integrato in Q1 e nuovo Q15_Portfolio_Backtest

[OB-2] Regime-Conditional Strategy Engine
        · RegimeStrategySelector: seleziona strategia in base al regime HMM corrente
        · Per ogni regime (bull/bear/transition/stress) → strategia diversa
        · Backtest con cambio dinamico di strategia al cambio di regime
        · Pagina: Q14 Strategy Lab aggiornata

[OB-3] Smart Rebalancing Engine
        · ThresholdRebalancer: soglia dinamica basata su regime e volatilità
        · CostBenefitAnalyzer: confronta drift penalty vs transaction cost
        · TaxAwareRebalancer: integra calcolo plusvalenze IT 26% nel suggerimento
        · Drift Monitor: serie storica del drift per ogni asset nel tempo

[OB-4] Feature Audit e Cleanup
        · Deprecare modelli DL inutilizzabili su CPU (LSTM, Transformer)
        · Aggiungere warning UI quando feature è degraded su questo hardware
        · Pulire code paths morti (Ollama, Transformer training)
        · Documentare chiaramente in vault v4.0 quali feature sono "active"

[OB-5] Q15 Portfolio Backtest — Nuova Pagina
        · Pagina dedicata al backtest di portafoglio multi-asset
        · Upload posizioni eToro come base portafoglio
        · Confronto: hold corrente vs portfolio ottimizzato backtestato
```

### Facoltativi (solo se OB-1/2/3/4 completi)

```
[OPT-1] Factor-Based Backtesting (Value, Momentum, Quality scoring)
[OPT-2] Event-Driven Backtesting su date FOMC/CPI configurabili
[OPT-3] Monte Carlo Rebalancing: simulazione distribuzioni di esiti post-ribilanciamento
```

---

## ⚠️ Vincoli Critici — LEGGERE PRIMA DI OGNI SESSIONE

```
PYTHON E DIPENDENZE:
  · Python venv: 3.12.10 SEMPRE (non 3.14.5 di sistema)
  · yfinance == 0.2.54 — NON toccare
  · websockets >= 12.0, <13.0 — NON toccare
  · pandera >= 0.18, <1.0 — NON toccare
  · DuckDB modifiche SOLO via migration SQL in shared/db/migrations/duckdb/

HARDWARE (limitazioni attive):
  · RX 6700 → ROCm su Windows instabile → PyTorch SEMPRE CPU-only
  · DL models (LSTM, N-BEATS): non abilitare di default, RAM > 4GB richiesta
  · Multi-asset backtesting su 20 asset × 10 anni: testare con max 10 asset
    per non saturare 16GB RAM con VectorBT vectorized tensors

ARCHITETTURA:
  · management_ui.py: ZERO import da engine/personal/shared (solo stdlib)
  · engine/ NON importa da personal/
  · personal/ NON importa da engine/analytics, risk, alpha_generation, backtesting
  · Bridge OBBLIGATORIO per comunicazione cross-layer

BACKTEST:
  · Regola 23 invariabile: fees ≥ 0.001, slippage ≥ 0.001 SEMPRE
  · signal.shift(1) SEMPRE (anti look-ahead bias)
  · Walk-forward obbligatorio per validazione OOS
```

---

## 🧩 Anti-Pattern Vietati v16.0.0

```
❌ PortfolioBacktester che non include costi di transazione per ogni rebalancing
   → CostConfig obbligatorio anche nel portfolio backtest

❌ RegimeStrategySelector che usa regime corrente per segnali passati (look-ahead)
   → Il regime al tempo T deve usare solo dati disponibili a T (shift regime labels)

❌ Smart Rebalancing che suggerisce trade senza CostBenefitAnalysis
   → estimated_cost sempre ≥ 0; trade suggerito solo se benefit > cost

❌ TaxAwareRebalancer che calcola plusvalenze senza data di acquisto
   → Ogni posizione DEVE avere acquisition_date e avg_cost dalla PersonalPortfolio

❌ PortfolioBacktester che modifica il DataFrame in-place
   → Sempre operare su copia; input immutabile (test verifica con .equals())

❌ Feature DL "deprecata" che resta comunque importata nel codice attivo
   → Rimuovere import, non solo il flag

❌ Drift monitor che salva un snapshot al giorno su SQLite senza limite
   → Retention: max 365 snapshots per profilo (pulizia automatica)

❌ Sessione Opus senza regression gate iniziale → 0 failed OBBLIGATORIO
```

---

## 📅 SESSIONE 1 — Portfolio Backtesting Engine: Foundation (1–2h)

**Obiettivo:** Creare il core del multi-asset portfolio backtester

**NON toccare:** `engine/analytics/backtesting/realistic_backtester.py` (lasciare invariato),
VectorBT setup esistente, pagine Q1/Q12 esistenti

**Prompt apertura Opus:**
```
Leggi CLAUDE.md e @.claude/02_architecture.md completamente.
Task: Sessione 1 v16 — Portfolio Backtesting Engine (foundation)
Gate: poetry run pytest -m regression -q --tb=short → 0 failed OBBLIGATORIO
NON toccare: realistic_backtester.py, Q1_Backtesting.py, pyproject.toml
Crea solo nuovi file in engine/analytics/backtesting/portfolio/
```

**File da creare:**

```
engine/analytics/backtesting/portfolio/
  __init__.py
  portfolio_backtester.py      ← PortfolioBacktester (motore principale)
  rebalancing_schedule.py      ← RebalancingSchedule (quando ribilanciare)
  portfolio_backtest_result.py ← PortfolioBacktestResult dataclass

tests/engine/backtesting/portfolio/
  __init__.py
  test_portfolio_backtester.py
  test_rebalancing_schedule.py
  fixtures/
    synthetic_portfolio.py     ← portafoglio sintetico per test (5 asset)
```

**portfolio_backtester.py — spec completo:**

```python
# engine/analytics/backtesting/portfolio/portfolio_backtester.py
"""PortfolioBacktester: backtest multi-asset con rebalancing periodico.

Differisce da RealisticBacktester (single asset) per:
  - Gestisce N asset contemporaneamente con pesi target
  - Esegue rebalancing secondo uno schedule configurabile
  - Calcola contribution per asset all'equity curve totale
  - Misura turnover cumulativo (costo opportunità del ribilanciamento)
  - Supporta asset con valute diverse via CurrencyConverter

Regola 23: CostConfig obbligatorio — mai backtest senza commissioni.
Regola anti look-ahead: i prezzi di rebalancing sono il close del giorno
                        SUCCESSIVO al segnale (shift obbligatorio).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import numpy as np
import pandas as pd
import structlog

from engine.analytics.backtesting.cost_model import CostConfig, CostModel
from engine.analytics.backtesting.portfolio.rebalancing_schedule import RebalancingSchedule
from shared.types import Currency
from shared.logger import get_logger

log = get_logger(__name__)


@dataclass
class PortfolioBacktestResult:
    """Risultato del backtest multi-asset."""

    # Equity curves
    equity_curve_gross: pd.Series       # patrimonio lordo (prima dei costi)
    equity_curve_net: pd.Series         # patrimonio netto (dopo tutti i costi)

    # Breakdown per asset
    asset_contributions: pd.DataFrame   # [T × n_assets] — contributo di ogni asset
    final_weights: dict[str, float]     # pesi finali alla fine del periodo

    # Metriche aggregate
    total_return_net: float             # rendimento totale netto
    cagr_net: float                     # CAGR annualizzato netto
    sharpe_ratio_net: float             # Sharpe sull'equity netta
    max_drawdown_net: float             # massimo drawdown netto
    calmar_ratio: float                 # CAGR / MaxDD (misura risk-adjusted)

    # Metriche di costo
    total_commission: float
    total_slippage: float
    n_rebalancing_events: int
    avg_turnover_per_rebalancing: float # % portafoglio ruotato ad ogni rebalancing
    total_turnover: float               # turnover cumulativo [0,1]

    # Confronto vs benchmark
    benchmark_return: float             # Buy & Hold equally weighted
    excess_return: float                # total_return_net - benchmark_return

    # Rebalancing log
    rebalancing_log: pd.DataFrame       # [data, asset, da_peso, a_peso, costo]


class PortfolioBacktester:
    """
    Backtest multi-asset con rebalancing periodico e costi realistici.

    Uso base:
        backtester = PortfolioBacktester(
            cost_config=CostConfig(commission_value=0.001),
            initial_capital=10_000.0,
        )
        result = backtester.run(
            prices=prices_df,         # [T × n_assets] prezzi daily
            target_weights={"SPY": 0.60, "GLD": 0.20, "TLT": 0.20},
            schedule=RebalancingSchedule(frequency="monthly"),
        )
    """

    def __init__(
        self,
        cost_config: Optional[CostConfig] = None,
        initial_capital: float = 10_000.0,
        base_currency: Currency = Currency.EUR,
    ) -> None:
        self._cost_model = CostModel(cost_config or CostConfig())
        self._capital = initial_capital
        self._base_currency = base_currency

    def run(
        self,
        prices: pd.DataFrame,                    # [T × n_assets] — close prices
        target_weights: dict[str, float],         # {"AAPL": 0.4, "GLD": 0.6}
        schedule: "RebalancingSchedule",
        volume: Optional[pd.DataFrame] = None,   # [T × n_assets] — per liquidità
        regime_labels: Optional[pd.Series] = None, # opzionale — per log
    ) -> PortfolioBacktestResult:
        """
        Esegue il backtest.

        ATTENZIONE: i prezzi vengono usati DAL GIORNO SUCCESSIVO alla
        decisione di rebalancing (built-in anti look-ahead bias).
        Non serve shift(1) esterno perché il rebalancing viene eseguito
        al close del giorno DOPO il trigger.
        """
        assert abs(sum(target_weights.values()) - 1.0) < 1e-6, \
            "I pesi target devono sommare a 1.0"
        assert all(col in prices.columns for col in target_weights), \
            "Tutti i ticker di target_weights devono essere in prices"
        assert (prices > 0).all().all(), "Prezzi non possono essere ≤ 0"

        tickers = list(target_weights.keys())
        weights = np.array([target_weights[t] for t in tickers])
        n_assets = len(tickers)
        n_days = len(prices)

        # Inizializzazione
        holdings = weights * self._capital / prices.iloc[0][tickers].values
        # holdings: numero di azioni per ogni asset
        portfolio_value = np.zeros(n_days)
        portfolio_value[0] = self._capital
        gross_value = np.zeros(n_days)
        gross_value[0] = self._capital
        total_cost_cumulative = 0.0

        rebalancing_dates = schedule.get_dates(prices.index)
        rebalancing_log_rows: list[dict] = []
        n_rebalancing = 0
        turnover_list: list[float] = []

        asset_values = np.zeros((n_days, n_assets))
        asset_values[0] = holdings * prices.iloc[0][tickers].values

        for i in range(1, n_days):
            day = prices.index[i]
            day_prices = prices.iloc[i][tickers].values

            # Aggiorna valore corrente prima del rebalancing
            current_values = holdings * day_prices
            total_value = current_values.sum()
            gross_value[i] = total_value

            # Check se oggi è un giorno di rebalancing
            if day in rebalancing_dates and i > 0:
                current_weights_now = current_values / (total_value + 1e-8)
                target_values = weights * total_value
                delta_values = target_values - current_values  # positivo = comprare

                trade_cost = 0.0
                turnover = 0.0

                for j, ticker in enumerate(tickers):
                    delta = delta_values[j]
                    if abs(delta) < 1.0:  # ignora trade troppo piccoli
                        continue

                    # Costo trade (commissione + slippage)
                    vol_j = None
                    if volume is not None and ticker in volume.columns:
                        vol_j = float(volume.iloc[i][ticker])

                    cost = self._cost_model.total_trade_cost(
                        price=day_prices[j],
                        quantity=abs(delta / day_prices[j]),
                        volatility=None,  # slippage fisso 0.1% per semplicità
                    )
                    trade_cost += cost
                    turnover += abs(delta) / total_value

                    rebalancing_log_rows.append({
                        "date": day,
                        "ticker": ticker,
                        "from_weight": float(current_weights_now[j]),
                        "to_weight": float(weights[j]),
                        "delta_eur": float(delta),
                        "cost_eur": float(cost),
                    })

                # Esegui rebalancing (ricalcola holdings dopo i costi)
                net_value_after_cost = total_value - trade_cost
                holdings = weights * net_value_after_cost / (day_prices + 1e-8)
                total_cost_cumulative += trade_cost
                n_rebalancing += 1
                turnover_list.append(turnover)

                log.info("portfolio_backtester.rebalancing",
                         date=str(day), cost=round(trade_cost, 2),
                         turnover=round(turnover, 4))

            # Aggiorna holdings e portfolio value
            current_values_after = holdings * day_prices
            portfolio_value[i] = current_values_after.sum()
            asset_values[i] = current_values_after

        # Costruzione risultati
        dates = prices.index
        equity_gross = pd.Series(gross_value, index=dates, name="equity_gross")
        equity_net   = pd.Series(portfolio_value, index=dates, name="equity_net")

        # Metriche
        returns_net = equity_net.pct_change().dropna()
        total_ret   = (equity_net.iloc[-1] / equity_net.iloc[0]) - 1
        n_years     = len(dates) / 252
        cagr        = (1 + total_ret) ** (1 / n_years) - 1
        sharpe      = (returns_net.mean() / (returns_net.std() + 1e-8)) * np.sqrt(252)
        drawdowns   = (equity_net / equity_net.cummax()) - 1
        max_dd      = float(drawdowns.min())
        calmar      = cagr / (abs(max_dd) + 1e-8)

        # Benchmark: equally weighted buy & hold
        bm_ew = prices[tickers].apply(lambda c: c / c.iloc[0]).mean(axis=1) * self._capital
        bm_return = float((bm_ew.iloc[-1] / bm_ew.iloc[0]) - 1)

        asset_contrib_df = pd.DataFrame(asset_values, index=dates, columns=tickers)

        return PortfolioBacktestResult(
            equity_curve_gross=equity_gross,
            equity_curve_net=equity_net,
            asset_contributions=asset_contrib_df,
            final_weights={t: float(v / portfolio_value[-1])
                          for t, v in zip(tickers, asset_values[-1])},
            total_return_net=float(total_ret),
            cagr_net=float(cagr),
            sharpe_ratio_net=float(sharpe),
            max_drawdown_net=float(max_dd),
            calmar_ratio=float(calmar),
            total_commission=float(total_cost_cumulative * 0.7),   # stima
            total_slippage=float(total_cost_cumulative * 0.3),
            n_rebalancing_events=n_rebalancing,
            avg_turnover_per_rebalancing=float(np.mean(turnover_list)) if turnover_list else 0.0,
            total_turnover=float(sum(turnover_list)),
            benchmark_return=float(bm_return),
            excess_return=float(total_ret - bm_return),
            rebalancing_log=pd.DataFrame(rebalancing_log_rows) if rebalancing_log_rows
                           else pd.DataFrame(),
        )
```

**rebalancing_schedule.py:**

```python
# engine/analytics/backtesting/portfolio/rebalancing_schedule.py
"""RebalancingSchedule: definisce quando il portafoglio viene ribilanciato."""
from __future__ import annotations
from typing import Literal
import pandas as pd

RebalancingFrequency = Literal["daily", "weekly", "monthly", "quarterly", "annual", "threshold"]

class RebalancingSchedule:
    """
    Definisce lo schedule di ribilanciamento per il PortfolioBacktester.

    Frequenze supportate:
      "daily"     → ribilanciamento ogni giorno (massimo turnover, massimi costi)
      "weekly"    → ogni lunedì
      "monthly"   → primo trading day del mese
      "quarterly" → primo trading day di gen/apr/lug/ott
      "annual"    → primo trading day di gennaio
      "threshold" → trigger quando il drift supera threshold_pct (gestito esternamente)
    """

    def __init__(
        self,
        frequency: RebalancingFrequency = "monthly",
        threshold_pct: float = 0.05,   # solo per frequency="threshold"
    ) -> None:
        self._freq = frequency
        self._threshold = threshold_pct

    def get_dates(self, date_index: pd.DatetimeIndex) -> set[pd.Timestamp]:
        """Ritorna il set di date in cui avviene il rebalancing."""
        if self._freq == "daily":
            return set(date_index)
        elif self._freq == "weekly":
            return {d for d in date_index if d.weekday() == 0}   # lunedì
        elif self._freq == "monthly":
            months_seen: set[tuple] = set()
            dates = set()
            for d in sorted(date_index):
                key = (d.year, d.month)
                if key not in months_seen:
                    months_seen.add(key)
                    dates.add(d)
            return dates
        elif self._freq == "quarterly":
            quarters_seen: set[tuple] = set()
            dates = set()
            for d in sorted(date_index):
                q = (d.year, (d.month - 1) // 3)
                if q not in quarters_seen:
                    quarters_seen.add(q)
                    dates.add(d)
            return dates
        elif self._freq == "annual":
            years_seen: set[int] = set()
            dates = set()
            for d in sorted(date_index):
                if d.year not in years_seen:
                    years_seen.add(d.year)
                    dates.add(d)
            return dates
        else:
            return set()   # "threshold" → gestito esternamente
```

**Definition of Done — Sessione 1:**

```
□ PortfolioBacktester.run(): backtest 5 asset × 5 anni < 5s (CPU)
□ equity_net sempre ≤ equity_gross (costi non negativi)
□ target_weights che non sommano a 1.0 → AssertionError chiaro
□ RebalancingSchedule: tutte le frequenze testate con date_index sintetico
□ PortfolioBacktestResult: tutti i campi popolati correttamente
□ test_portfolio_backtester.py: ≥ 8 test (inclusi edge cases: 1 asset, 0 rebalancing)
□ pytest -m regression: 0 failed
□ mypy --strict su portfolio/: 0 errors
□ Coverage portfolio/: 100%
```

---

## 📅 SESSIONE 2 — Regime-Conditional Strategy Engine (1–2h)

**Obiettivo:** Creare il selettore di strategie che cambia in base al regime HMM

**NON toccare:** pipeline HMM esistente, pagine E1/Q1/Q3

**File da creare:**

```
engine/analytics/backtesting/
  regime_strategy_selector.py    ← RegimeStrategySelector
  regime_conditional_backtest.py ← backtest con cambio dinamico di strategia

tests/engine/backtesting/
  test_regime_strategy_selector.py
  test_regime_conditional_backtest.py
```

**regime_strategy_selector.py:**

```python
# engine/analytics/backtesting/regime_strategy_selector.py
"""RegimeStrategySelector: seleziona la strategia ottimale per il regime corrente.

Motivazione: una strategia MA Cross funziona bene in regime "bull" ma è
disastrosa in regime "stress". Questo modulo permette di definire una
strategia diversa per ogni regime e di fare un backtest che cambia
automaticamente strategia al cambio di regime.

REGOLA CRITICA: il regime al tempo T deve essere calcolato solo con dati
disponibili a T. Il regime viene shiftato di 1 giorno per evitare look-ahead:
    regime_shifted = regime_labels.shift(1)
    Il backtest usa regime_shifted[t] per decidere la strategia al giorno t.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
import pandas as pd
import numpy as np
import structlog

log = structlog.get_logger(__name__)

# Una strategia è una funzione che prende i prezzi e ritorna segnali
StrategyFn = Callable[[pd.DataFrame], pd.Series]


@dataclass
class RegimeStrategyMap:
    """Mappa regime → strategia da usare in quel regime."""
    bull: StrategyFn        # strategia in mercato rialzista
    bear: StrategyFn        # strategia in mercato ribassista
    transition: StrategyFn  # strategia in fase di transizione
    stress: StrategyFn      # strategia in crisi (es. cash/short solo)

    def get_for_regime(self, regime: str) -> StrategyFn:
        mapping = {
            "bull": self.bull,
            "bear": self.bear,
            "transition": self.transition,
            "stress": self.stress,
        }
        if regime not in mapping:
            log.warning("regime_selector.unknown_regime",
                        regime=regime, fallback="transition")
            return self.transition
        return mapping[regime]


class RegimeStrategySelector:
    """
    Produce segnali di trading combinando più strategie in base al regime.

    Uso:
        selector = RegimeStrategySelector(strategy_map)
        signals = selector.generate_signals(
            prices=prices_df,
            regime_labels=regime_series,  # raw labels dall'HMM
        )
        # Poi backtest su `signals` con RealisticBacktester o PortfolioBacktester
    """

    def __init__(self, strategy_map: RegimeStrategyMap) -> None:
        self._map = strategy_map

    def generate_signals(
        self,
        prices: pd.DataFrame,
        regime_labels: pd.Series,    # index: DatetimeIndex, values: str
    ) -> pd.Series:
        """
        Genera segnali combinati.

        1. Shifta il regime di 1 giorno (anti look-ahead).
        2. Per ogni regime, applica la strategia corrispondente.
        3. Combina i segnali selezionando quello del regime corrente.
        4. Shifta il segnale finale di 1 giorno (anti look-ahead aggiuntivo).
        """
        # CRITICO: shift regime labels di 1 per evitare look-ahead
        regime_shifted = regime_labels.shift(1).fillna("transition")
        combined_signal = pd.Series(0.0, index=prices.index)

        # Calcola segnali per ogni regime (su tutti i dati)
        regimes = ["bull", "bear", "transition", "stress"]
        regime_signals: dict[str, pd.Series] = {}
        for regime_name in regimes:
            strategy_fn = self._map.get_for_regime(regime_name)
            sig = strategy_fn(prices)
            regime_signals[regime_name] = sig

        # Seleziona il segnale del regime corrente per ogni data
        for date in prices.index:
            current_regime = str(regime_shifted.get(date, "transition"))
            if date in regime_signals.get(current_regime, {}).index:
                combined_signal[date] = float(
                    regime_signals[current_regime].get(date, 0.0)
                )

        # Shift finale del segnale (anti look-ahead per esecuzione)
        return combined_signal.shift(1).fillna(0.0)

    def regime_performance_breakdown(
        self,
        prices: pd.Series,
        signals: pd.Series,
        regime_labels: pd.Series,
    ) -> pd.DataFrame:
        """
        Calcola la performance della strategia breakdown per regime.
        Ritorna DataFrame con: regime, n_days, avg_daily_return, sharpe.
        """
        regime_shifted = regime_labels.shift(1).fillna("transition")
        returns = prices.pct_change() * signals.shift(1)

        rows = []
        for regime_name in ["bull", "bear", "transition", "stress"]:
            mask = regime_shifted == regime_name
            regime_returns = returns[mask]
            if len(regime_returns) < 5:
                continue
            rows.append({
                "regime": regime_name,
                "n_days": int(mask.sum()),
                "avg_daily_return_pct": float(regime_returns.mean() * 100),
                "sharpe": float(
                    regime_returns.mean() / (regime_returns.std() + 1e-8) * np.sqrt(252)
                ),
                "positive_days_pct": float((regime_returns > 0).mean() * 100),
            })
        return pd.DataFrame(rows)
```

**Strategie standard pre-definite da usare con RegimeStrategyMap:**

```python
# engine/analytics/backtesting/strategies/regime_strategies.py
"""Strategie predefinite per ogni regime di mercato.

Queste sono raccomandazioni basate sulla letteratura accademica.
Personalizzabili via Q14 Strategy Lab.
"""
import numpy as np
import pandas as pd
import ta  # type: ignore[import]

def bull_ma_cross(prices: pd.DataFrame, fast: int = 20, slow: int = 60) -> pd.Series:
    """In bull market: MA Cross aggressivo (short windows)."""
    close = prices["Close"] if "Close" in prices.columns else prices.iloc[:, 0]
    ema_fast = close.ewm(span=fast).mean()
    ema_slow = close.ewm(span=slow).mean()
    return pd.Series(
        np.where(ema_fast > ema_slow, 1.0, -1.0),
        index=prices.index,
    )

def bear_momentum_reversal(prices: pd.DataFrame) -> pd.Series:
    """In bear market: contrarian momentum (short quando prezzo sale molto)."""
    close = prices["Close"] if "Close" in prices.columns else prices.iloc[:, 0]
    returns_5d = close / close.shift(5) - 1
    signal = pd.Series(0.0, index=prices.index)
    signal[returns_5d > 0.03] = -1.0  # prezzo salito > 3% → short (mean reversion)
    signal[returns_5d < -0.03] = 1.0  # prezzo sceso > 3% → long (oversold)
    return signal

def transition_rsi_neutral(prices: pd.DataFrame) -> pd.Series:
    """In transizione: RSI mean reversion, flat in zona neutrale."""
    close = prices["Close"] if "Close" in prices.columns else prices.iloc[:, 0]
    rsi = ta.momentum.RSIIndicator(close, window=14).rsi()
    signal = pd.Series(0.0, index=prices.index)
    signal[rsi < 30] = 1.0   # oversold
    signal[rsi > 70] = -1.0  # overbought
    return signal

def stress_defensive_cash(prices: pd.DataFrame) -> pd.Series:
    """In stress: cash (flat) — no exposure durante crisi acute."""
    return pd.Series(0.0, index=prices.index)

# Default strategy map (modificabile dall'utente)
DEFAULT_REGIME_STRATEGY_MAP = RegimeStrategyMap(
    bull=bull_ma_cross,
    bear=bear_momentum_reversal,
    transition=transition_rsi_neutral,
    stress=stress_defensive_cash,
)
```

**Definition of Done — Sessione 2:**

```
□ RegimeStrategySelector.generate_signals(): shift regime VERIFICATO (test esplicito)
□ regime_performance_breakdown(): DataFrame con 4 righe (una per regime)
□ DEFAULT_REGIME_STRATEGY_MAP: tutte e 4 le strategie importabili e funzionanti
□ test_regime_strategy_selector.py:
    - test_no_lookahead_regime: regime_shifted[0] = NaN/transition (non usa dati futuri)
    - test_bull_strategy_applied_in_bull_regime
    - test_stress_gives_flat_signal
    - test_performance_breakdown_returns_4_regimes
□ pytest -m regression: 0 failed
□ mypy --strict: 0 errors sui nuovi file
```

---

## 📅 SESSIONE 3 — Smart Rebalancing Engine: Threshold Dinamica (1–2h)

**Obiettivo:** Creare il rebalancing engine con soglia che si adatta al regime e ai costi

**NON toccare:** RebalancingAdvisor esistente (compatibilità), portfolio optimizer

**File da creare:**

```
personal/allocator/
  smart_rebalancer.py          ← SmartRebalancer (threshold dinamica + cost-benefit)
  cost_benefit_analyzer.py     ← CostBenefitAnalyzer
  drift_monitor.py             ← DriftMonitor (serie storica drift)

tests/personal/allocator/
  test_smart_rebalancer.py
  test_cost_benefit_analyzer.py
  test_drift_monitor.py
```

**smart_rebalancer.py:**

```python
# personal/allocator/smart_rebalancer.py
"""SmartRebalancer: rebalancing con soglia dinamica basata su regime e volatilità.

Il RebalancingAdvisor esistente usa una soglia fissa (5%).
SmartRebalancer adatta la soglia in base a:
  1. Regime di mercato: in stress → soglia aumenta (ridurre costi in crisi)
  2. Volatilità corrente: alta volatilità → soglia aumenta (drift più veloce, costi alti)
  3. Costi stimati: ribilanciamento suggerito SOLO se benefit > cost

Principio: ribilanciare costa. Se il drift è piccolo o i costi sono alti,
           è spesso meglio aspettare.

Parametri di default basati su letteratura accademica (Vanguard, 2010):
  - Soglia base: 5% (range storico 2–10%)
  - Incremento per regime stress: +5% (ridurre operatività in crisi)
  - Incremento per volatilità alta (VIX > 30): +3%
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import structlog
from personal.investor_profile.profile_model import InvestorProfile

log = structlog.get_logger(__name__)

@dataclass
class RebalancingRecommendation:
    needs_rebalancing: bool
    dynamic_threshold: float           # soglia usata per questa decisione
    drift_by_asset: dict[str, float]   # quanto si è spostato ogni asset
    suggested_trades: list[dict]       # [{"ticker", "from_w", "to_w", "delta_eur"}]
    estimated_cost_eur: float          # costo stimato del ribilanciamento
    estimated_benefit_eur: float       # beneficio stimato (riduzione drift penalty)
    cost_benefit_ratio: float          # estimated_cost / estimated_benefit
    rationale: str                     # spiegazione leggibile
    regime: str                        # regime di mercato al momento della decisione


class SmartRebalancer:
    """
    Rebalancing advisor con soglia dinamica basata su regime e costi.

    Eredita la logica base da RebalancingAdvisor (compatibilità)
    ma aggiunge: soglia dinamica, analisi costi-benefici, regime awareness.

    BOUNDARY: questo modulo vive in personal/ ma legge il regime
              SOLO via bridge/api_contracts.py (non importa engine/).
    """

    # Aggiustamenti soglia per regime
    REGIME_THRESHOLD_DELTA: dict[str, float] = {
        "bull":       0.00,   # soglia base
        "bear":       0.02,   # +2% → meno aggressivo in ribasso
        "transition": 0.03,   # +3% → mercato incerto, ridurre operazioni
        "stress":     0.05,   # +5% → crisi, quasi nessun ribilanciamento
    }

    def __init__(
        self,
        base_threshold: float = 0.05,
        min_trade_eur: float = 50.0,     # trade sotto questa soglia ignorati
        commission_rate: float = 0.001,  # 0.1% per stimare i costi
    ) -> None:
        self._base_threshold = base_threshold
        self._min_trade = min_trade_eur
        self._comm_rate = commission_rate

    def check(
        self,
        current_weights: dict[str, float],
        target_weights: dict[str, float],
        portfolio_value_eur: float,
        regime: str = "transition",
        vix: Optional[float] = None,
        investor_profile: Optional[InvestorProfile] = None,
    ) -> RebalancingRecommendation:
        """
        Valuta se è necessario ribilanciare.

        Args:
            current_weights: pesi correnti {'AAPL': 0.45, 'GLD': 0.55}
            target_weights: pesi target {'AAPL': 0.40, 'GLD': 0.60}
            portfolio_value_eur: valore totale portafoglio in EUR
            regime: regime di mercato corrente (da bridge)
            vix: livello VIX corrente (opzionale, per aggiustamento soglia)
            investor_profile: profilo investitore (per filtro suitability)
        """
        # Calcolo soglia dinamica
        dynamic_threshold = self._base_threshold
        dynamic_threshold += self.REGIME_THRESHOLD_DELTA.get(regime, 0.0)

        # Aggiustamento per VIX alta
        if vix is not None and vix > 30:
            dynamic_threshold += 0.03
            log.debug("smart_rebalancer.vix_adjustment", vix=vix, delta=0.03)

        # Aggiustamento per profilo conservativo
        if investor_profile and investor_profile.risk_tolerance.value == "conservative":
            dynamic_threshold += 0.02   # conservativo: riduci operatività

        # Calcolo drift per asset
        all_tickers = set(current_weights) | set(target_weights)
        drift_by_asset = {
            t: abs(current_weights.get(t, 0.0) - target_weights.get(t, 0.0))
            for t in all_tickers
        }
        max_drift = max(drift_by_asset.values()) if drift_by_asset else 0.0

        # Nessun ribilanciamento se drift sotto soglia
        if max_drift < dynamic_threshold:
            return RebalancingRecommendation(
                needs_rebalancing=False,
                dynamic_threshold=dynamic_threshold,
                drift_by_asset=drift_by_asset,
                suggested_trades=[],
                estimated_cost_eur=0.0,
                estimated_benefit_eur=0.0,
                cost_benefit_ratio=0.0,
                rationale=(
                    f"Drift massimo ({max_drift:.1%}) sotto soglia dinamica "
                    f"({dynamic_threshold:.1%}). Regime: {regime}."
                ),
                regime=regime,
            )

        # Calcolo trade suggeriti e stima costi
        suggested_trades = []
        total_cost = 0.0
        for ticker in all_tickers:
            from_w = current_weights.get(ticker, 0.0)
            to_w = target_weights.get(ticker, 0.0)
            delta_w = to_w - from_w
            if abs(delta_w) < 0.001:  # ignora micro-drift
                continue
            delta_eur = delta_w * portfolio_value_eur
            if abs(delta_eur) < self._min_trade:
                continue
            cost = abs(delta_eur) * self._comm_rate
            total_cost += cost
            suggested_trades.append({
                "ticker": ticker,
                "from_weight": from_w,
                "to_weight": to_w,
                "delta_eur": delta_eur,
                "estimated_cost_eur": cost,
            })

        # Stima beneficio (approssimazione: drift² × portfolio_value × risk_penalty)
        # Fonte: Perold & Sharpe (1988): cost of underrebalancing ≈ vol² × drift²
        estimated_benefit = (max_drift ** 2) * portfolio_value_eur * 0.5

        cb_ratio = total_cost / (estimated_benefit + 1e-8)
        rebalance_now = (
            len(suggested_trades) > 0 and
            (cb_ratio < 0.5 or max_drift > dynamic_threshold * 2)
        )

        rationale_parts = [
            f"Drift massimo: {max_drift:.1%} (soglia: {dynamic_threshold:.1%}).",
            f"Regime: {regime}.",
            f"Costo stimato: {total_cost:.2f} EUR.",
            f"Beneficio stimato: {estimated_benefit:.2f} EUR.",
            f"Ratio costo/beneficio: {cb_ratio:.2f}.",
        ]
        if not rebalance_now:
            rationale_parts.append(
                "⚠️ Ratio > 0.5: i costi superano il beneficio. Valutare di aspettare."
            )

        return RebalancingRecommendation(
            needs_rebalancing=rebalance_now,
            dynamic_threshold=dynamic_threshold,
            drift_by_asset=drift_by_asset,
            suggested_trades=suggested_trades,
            estimated_cost_eur=total_cost,
            estimated_benefit_eur=estimated_benefit,
            cost_benefit_ratio=cb_ratio,
            rationale=" ".join(rationale_parts),
            regime=regime,
        )
```

**Definition of Done — Sessione 3:**

```
□ SmartRebalancer: soglia in stress > soglia in bull (verificato con test)
□ Cost-benefit ratio < 0.5 → needs_rebalancing = True solo se drift > 2× soglia
□ VIX > 30 → soglia incrementa di 3% (test con mock VIX)
□ Profilo conservativo → soglia +2%
□ min_trade_eur rispettato: nessun trade sotto 50 EUR nei suggested_trades
□ test_smart_rebalancer.py: ≥ 10 test
□ DriftMonitor: salva snapshot giornaliero su user_sessions.db (max 365)
□ pytest -m regression: 0 failed
□ Layer boundary verificata: smart_rebalancer.py NON importa da engine/
```

---

## 📅 SESSIONE 4 — Tax-Aware Rebalancing (Regime Fiscale IT) (1–2h)

**Obiettivo:** Integrare il calcolo delle plusvalenze IT nel motore di rebalancing

**NON toccare:** tax/calculator.py esistente (backward compat), personal/goals/

**File da creare/modificare:**

```
personal/allocator/
  tax_aware_rebalancer.py      ← TaxAwareRebalancer (NUOVO)
personal/tax/
  capital_gains_estimator.py   ← stima plusvalenze prima della vendita (NUOVO)

tests/personal/
  test_tax_aware_rebalancer.py
  test_capital_gains_estimator.py
```

**capital_gains_estimator.py:**

```python
# personal/tax/capital_gains_estimator.py
"""Stima plusvalenze (e minusvalenze) prima di eseguire il ribilanciamento.

Regime fiscale IT (dichiarativo):
  - Plusvalenza = (prezzo vendita - prezzo acquisto) × quantità
  - Aliquota: 26% su plusvalenze nette (capital gain - capital loss)
  - Minusvalenze: compensabili con plusvalenze entro 4 anni successivi

Questo modulo STIMA le tasse PRIMA del trade, permettendo al
TaxAwareRebalancer di scegliere quali posizioni vendere per
minimizzare l'impatto fiscale (tax-loss harvesting opportunistico).
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from typing import Optional
import numpy as np

IT_CAPITAL_GAIN_TAX_RATE = 0.26  # 26% aliquota IT standard


@dataclass
class PositionTaxInfo:
    """Informazioni fiscali di una posizione aperta."""
    ticker: str
    quantity: float
    avg_acquisition_cost: float   # prezzo medio di carico in EUR
    acquisition_date: date
    current_price_eur: float

    @property
    def unrealized_gain_eur(self) -> float:
        """Plusvalenza non realizzata attuale."""
        return (self.current_price_eur - self.avg_acquisition_cost) * self.quantity

    @property
    def is_gain(self) -> bool:
        return self.unrealized_gain_eur > 0

    @property
    def estimated_tax_eur(self) -> float:
        """Tassa stimata se la posizione venisse venduta ora."""
        if self.unrealized_gain_eur <= 0:
            return 0.0  # minusvalenza: non si paga tassa (anzi, si accumula credito)
        return self.unrealized_gain_eur * IT_CAPITAL_GAIN_TAX_RATE

    @property
    def net_proceeds_eur(self) -> float:
        """Incasso netto stimato dopo le tasse."""
        return (self.current_price_eur * self.quantity) - self.estimated_tax_eur


class CapitalGainsEstimator:
    """
    Stima l'impatto fiscale di un set di operazioni di vendita.

    Usa il metodo FIFO (First In, First Out) per identificare
    quale "lotto" di acquisto viene venduto per primo.
    """

    def estimate_for_trade(
        self,
        position: PositionTaxInfo,
        quantity_to_sell: float,
    ) -> dict:
        """
        Stima plusvalenza/minusvalenza per una vendita parziale.

        Returns:
            dict con: gain_eur, tax_eur, is_loss, net_after_tax_eur
        """
        if quantity_to_sell > position.quantity:
            raise ValueError(
                f"Quantità da vendere ({quantity_to_sell}) > "
                f"quantità posseduta ({position.quantity}) per {position.ticker}"
            )
        gain_eur = (position.current_price_eur - position.avg_acquisition_cost) * quantity_to_sell
        tax_eur = max(0.0, gain_eur) * IT_CAPITAL_GAIN_TAX_RATE
        return {
            "ticker": position.ticker,
            "quantity_sold": quantity_to_sell,
            "gain_eur": float(gain_eur),
            "tax_eur": float(tax_eur),
            "is_loss": gain_eur < 0,
            "loss_credit_eur": float(abs(min(0.0, gain_eur))),  # credito da compensare
            "net_after_tax_eur": float(position.current_price_eur * quantity_to_sell - tax_eur),
        }

    def tax_optimal_sell_order(
        self,
        positions: list[PositionTaxInfo],
        target_sell_eur: float,
    ) -> list[dict]:
        """
        Ordina le posizioni da vendere per minimizzare l'impatto fiscale.

        Strategia: vendi prima le posizioni in perdita (minusvalenze),
        poi quelle con minor plusvalenza, lasciando le più profittevoli.

        Questo è il nucleo del tax-loss harvesting opportunistico.
        """
        # Ordina: prima le minusvalenze (gain negativo), poi le plusvalenze minori
        sorted_positions = sorted(
            positions,
            key=lambda p: p.unrealized_gain_eur
        )

        sell_plan = []
        remaining = target_sell_eur
        for pos in sorted_positions:
            if remaining <= 0:
                break
            sell_value = min(pos.current_price_eur * pos.quantity, remaining)
            qty_to_sell = sell_value / (pos.current_price_eur + 1e-8)
            trade_info = self.estimate_for_trade(pos, qty_to_sell)
            sell_plan.append(trade_info)
            remaining -= sell_value

        return sell_plan
```

**Definition of Done — Sessione 4:**

```
□ CapitalGainsEstimator: plusvalenza IT al 26% calcolata correttamente
□ tax_optimal_sell_order(): minusvalenze vendute prima (verificato con test)
□ TaxAwareRebalancer: integra stima fiscale nel RebalancingRecommendation
□ Minusvalenza genera loss_credit (non imposta) — verificato
□ test_capital_gains_estimator.py:
    - test_gain_taxed_at_26pct: plusvalenza × 0.26 = tax
    - test_loss_generates_no_tax: minusvalenza → tax = 0
    - test_sell_order_prioritizes_losses: posizioni in perdita vendute prime
□ pytest -m regression: 0 failed
□ layer boundary: capital_gains_estimator.py vive in personal/, NON in engine/
```

---

## 📅 SESSIONE 5 — Feature Audit e Cleanup (1–2h)

**Obiettivo:** Deprecare le feature non funzionali su questo hardware,
pulire code paths morti, documentare chiaramente lo stato di ogni feature

**NON toccare:** architettura generale, pagine Q1/E*, funzionalità attive

**File da creare/modificare:**

```
config/
  feature_flags.yaml           ← aggiornare con stati corretti (MODIFICA)
  hardware_capabilities.yaml   ← NUOVO: mappa hardware → feature disponibili
shared/
  hardware_check.py            ← NUOVO: verifica capacità hardware a runtime
presentation/ui/components/
  hardware_warning.py          ← NUOVO: banner UI quando feature degraded

engine/analytics/forecasting/
  lstm_model.py                ← aggiungere deprecation warning (MODIFICA)
  transformer_model.py         ← aggiungere deprecation warning (MODIFICA)
```

**config/feature_flags.yaml — versione aggiornata:**

```yaml
# config/feature_flags.yaml — v16.0.0
# NOTA: questo file riflette la realtà dell'hardware Ryzen 5 5600 / 16GB RAM
# Modificare manualmente solo se si aggiorna l'hardware.

# ═══ FUNZIONANTI ═══════════════════════════════════════════════════════════════
ensemble_predictor: true           # OK — CPU-friendly
auto_feature_engineering: true    # OK — numpy vettorizzato
realistic_backtester: true        # OK — event-driven CPU
portfolio_backtester: true        # OK — NUOVO v16
regime_strategy_selector: true    # OK — NUOVO v16
smart_rebalancer: true            # OK — NUOVO v16
tax_aware_rebalancer: true        # OK — NUOVO v16
fastapi_backend: false            # avviare manualmente con Management UI

# ═══ SPERIMENTALI (attivare con cautela) ════════════════════════════════════
nbeats_model: false               # CPU: ~3 min fit, hidden_size ≤ 128 SOLO
                                  # Attivare solo con > 6GB RAM libera
advanced_correlation_dcc: true    # OK ma lento: < 10s su 20 asset
realtime_websocket: true          # OK con Finnhub free tier

# ═══ DEPRECATI (NON USARE) ══════════════════════════════════════════════════
lstm_model: false                 # DEPRECATED: training > 10 min su CPU
                                  # Rimosso dalla UI — solo ricerca futura
cnn_lstm_model: false             # DEPRECATED: same problema lstm
transformer_model: false          # DEPRECATED: attention CPU troppo lento
                                  # Per uso futuro quando GPU ROCm stabile
ollama_narrative: false           # DEPRECATED: richiede Ollama separato
                                  # Rimosso dai code paths attivi
pytorch_forecasting: false        # DEPRECATED: TFT troppo pesante su 16GB
                                  # Rivalutare con GPU upgrade hardware

# ═══ FUTURE (non ancora implementate) ═══════════════════════════════════════
factor_backtesting: false         # v16 OPT-1 (Fama-French)
event_driven_backtest: false      # v16 OPT-2 (FOMC/CPI)
monte_carlo_rebalancing: false    # v16 OPT-3
```

**config/hardware_capabilities.yaml — NUOVO:**

```yaml
# config/hardware_capabilities.yaml
# Mappa automatica: hardware presente → funzionalità disponibili
# Questo file viene letto da hardware_check.py all'avvio

hardware:
  cpu: "Ryzen 5 5600"
  cpu_cores: 6
  cpu_threads: 12
  ram_gb: 16
  gpu: "RX 6700 8GB"
  gpu_api: "None"          # ROCm non stabile su Windows 11 → None
  storage_nvme_gb: 512

# Limiti operativi derivati dall'hardware
operational_limits:
  max_dl_hidden_size: 128           # sopra: rischio OOM
  max_dl_batch_size: 32
  max_portfolio_assets: 30          # sopra: VectorBT RAM issues
  max_backtest_years: 20            # 20 anni daily = ~5000 righe × n_assets
  max_concurrent_model_fits: 2      # più di 2 → RAM saturata
  nbeats_max_lookback: 30           # ridotto per CPU-only
  dl_training_warning_threshold_s: 60  # warning se training supera 60s

# Avvertenze da mostrare in UI quando una feature è "degradata"
degraded_features:
  nbeats_model:
    warning: "⚠️ N-BEATS su CPU: training può richiedere 3+ minuti. Consigliato lookback ≤ 30."
  lstm_model:
    warning: "❌ LSTM deprecato su questo hardware. Training > 10 min. Usa XGBoost o Ensemble."
  transformer_model:
    warning: "❌ Transformer deprecato su questo hardware. Usa EnsemblePredictor."
  ollama_narrative:
    warning: "❌ Narrativa LLM disabilitata. Ollama non installato."
```

**shared/hardware_check.py:**

```python
# shared/hardware_check.py
"""Verifica capacità hardware e avverte se feature non sono supportate.

Chiamato all'avvio da app_unified.py.
Pubblica avvertenze su SignalBus per la UI.
"""
from __future__ import annotations
from pathlib import Path
import yaml
import structlog

log = structlog.get_logger(__name__)
_CONFIG_PATH = Path("config/hardware_capabilities.yaml")


def load_hardware_config() -> dict:
    if not _CONFIG_PATH.exists():
        log.warning("hardware_check.config_missing")
        return {}
    return yaml.safe_load(_CONFIG_PATH.read_text()) or {}


def check_feature_hardware_support(feature_name: str) -> tuple[bool, str]:
    """
    Verifica se una feature è supportata dall'hardware corrente.

    Returns:
        (is_supported, warning_message)
        is_supported = False → mostrare banner degraded in UI
    """
    config = load_hardware_config()
    degraded = config.get("degraded_features", {})
    if feature_name in degraded:
        return False, degraded[feature_name]["warning"]
    return True, ""


def get_operational_limit(limit_name: str) -> int | float | None:
    """Legge un limite operativo dalla configurazione hardware."""
    config = load_hardware_config()
    return config.get("operational_limits", {}).get(limit_name)
```

**Definition of Done — Sessione 5:**

```
□ feature_flags.yaml: tutti i flag DL deprecati → false con commento esplicito
□ hardware_capabilities.yaml: creato e caricabile da hardware_check.py
□ lstm_model.py e transformer_model.py: aggiunto deprecation warning alla prima riga
□ hardware_warning.py: componente Streamlit mostra banner se feature degraded
□ Ollama code path rimosso dai file attivi (rimane solo in feature_flags come false)
□ Verifica: grep -r "ollama" engine/ → solo file di config, nessun import attivo
□ pytest -m regression: 0 failed (nessun modulo rimosso da import circolari)
□ Vault v4.0 update checklist: aggiornare Modules/ per ogni feature deprecata
```

---

## 📅 SESSIONE 6 — Q15 Portfolio Backtest — Nuova Pagina Dashboard (1–2h)

**Obiettivo:** Creare la pagina dedicata al backtest di portafoglio con integrazione eToro

**NON toccare:** pagine esistenti Q1/Q12/Q14, personal/ layer (usare bridge)

**File da creare:**

```
presentation/dashboard_engine/pages/
  Q15_Portfolio_Backtest.py    ← NUOVO: pagina backtest multi-asset

presentation/ui/components/
  portfolio_equity_chart.py    ← NUOVO: fan chart equity curve + benchmark
  rebalancing_log_table.py     ← NUOVO: tabella operazioni di ribilanciamento
  asset_contribution_chart.py  ← NUOVO: area chart contributo per asset
```

**Q15_Portfolio_Backtest.py — spec:**

```python
# presentation/dashboard_engine/pages/Q15_Portfolio_Backtest.py
"""Pagina Q15 — Portfolio Backtesting.

Permette di:
1. Definire un portafoglio multi-asset con pesi target
2. Scegliere frequenza di ribilanciamento e costi
3. Eseguire backtest con PortfolioBacktester
4. Visualizzare: equity curve, contributi per asset, log ribilanciamenti

OPZIONE INTEGRAZIONE eToro:
  Se l'utente ha importato le posizioni in P2, può usarle come punto
  di partenza (pesi correnti) e confrontarle con pesi ottimizzati da Q4.
"""
import streamlit as st
from presentation.ui.auth import require_auth
from presentation.ui.cache_policy import CACHE_TTL
from presentation.ui.session_keys import SK

require_auth()
st.title("📊 Q15 — Portfolio Backtesting")

# ──────────────────────────────────────────────
# Sidebar: configurazione
# ──────────────────────────────────────────────
with st.sidebar:
    st.subheader("⚙️ Configurazione")

    # Portfolio: inserimento manuale o da eToro
    portfolio_source = st.radio(
        "Portafoglio base",
        options=["Manuale", "Da posizioni eToro (P2)"],
        index=0,
        key="q15_portfolio_source",
    )

    if portfolio_source == "Manuale":
        st.markdown("**Ticker e pesi target:**")
        n_assets = st.number_input("Numero di asset", min_value=2, max_value=20, value=4)
        tickers = []
        weights_input = []
        for i in range(int(n_assets)):
            col_t, col_w = st.columns([2, 1])
            with col_t:
                t = st.text_input(f"Ticker {i+1}", value=["SPY", "GLD", "TLT", "QQQ"][i] if i < 4 else "")
            with col_w:
                w = st.number_input(f"Peso {i+1}", min_value=0.0, max_value=1.0,
                                    value=round(1.0 / n_assets, 2), step=0.05)
            if t:
                tickers.append(t)
                weights_input.append(w)
    else:
        st.info("Carica prima le posizioni in P2 Portfolio eToro.")
        tickers = []   # popolato da bridge/api_contracts

    start_date = st.date_input("Data inizio backtest", value=pd.Timestamp("2019-01-01"))
    end_date   = st.date_input("Data fine backtest",   value=pd.Timestamp.today())

    st.divider()
    st.subheader("💸 Costi")
    commission_pct = st.slider("Commissione (%)", 0.05, 0.50, 0.10, 0.05)
    initial_capital = st.number_input("Capitale iniziale (EUR)", 1000, 1_000_000, 10_000)

    st.divider()
    st.subheader("🔄 Ribilanciamento")
    rebal_freq = st.selectbox(
        "Frequenza",
        options=["monthly", "quarterly", "annual", "weekly"],
        index=1,
    )

    run_btn = st.button("▶️ Esegui Backtest", type="primary", key="q15_run")

# ──────────────────────────────────────────────
# Main: risultati
# ──────────────────────────────────────────────
if run_btn and len(tickers) >= 2:
    total_w = sum(weights_input)
    if abs(total_w - 1.0) > 0.02:
        st.error(f"I pesi sommano a {total_w:.2f} invece di 1.00. Correggere.")
    else:
        # Normalizzazione automatica
        normalized_weights = {t: w / total_w for t, w in zip(tickers, weights_input)}

        with st.spinner("Scaricamento dati e backtest in corso..."):
            # Fetch prezzi
            from engine.market_data.providers.registry import ProviderRegistry
            registry = ProviderRegistry.get_instance()
            prices_data = {}
            for ticker in tickers:
                try:
                    df = registry.get_history(ticker, str(start_date), str(end_date))
                    prices_data[ticker] = df["Close"]
                except Exception as e:
                    st.warning(f"⚠️ Impossibile scaricare {ticker}: {e}")

            if len(prices_data) < 2:
                st.error("Almeno 2 asset con dati disponibili sono necessari.")
            else:
                prices_df = pd.DataFrame(prices_data).dropna()

                # Run backtest
                from engine.analytics.backtesting.portfolio.portfolio_backtester import PortfolioBacktester
                from engine.analytics.backtesting.portfolio.rebalancing_schedule import RebalancingSchedule
                from engine.analytics.backtesting.cost_model import CostConfig

                cost_cfg = CostConfig(
                    commission_value=commission_pct / 100,
                    slippage_type="fixed",
                    slippage_pct=0.001,
                )
                backtester = PortfolioBacktester(cost_config=cost_cfg, initial_capital=initial_capital)
                schedule   = RebalancingSchedule(frequency=rebal_freq)
                result     = backtester.run(prices_df, normalized_weights, schedule)

        # ── KPI principali ──────────────────────────────────
        kpi1, kpi2, kpi3, kpi4 = st.columns(4)
        kpi1.metric("Rendimento Netto",
                    f"{result.total_return_net:.1%}",
                    f"vs Benchmark: {result.excess_return:+.1%}")
        kpi2.metric("CAGR Netto", f"{result.cagr_net:.1%}")
        kpi3.metric("Sharpe Netto", f"{result.sharpe_ratio_net:.2f}")
        kpi4.metric("Max Drawdown", f"{result.max_drawdown_net:.1%}")

        st.divider()
        kpi5, kpi6, kpi7 = st.columns(3)
        kpi5.metric("Costo Totale", f"{result.total_commission + result.total_slippage:.0f} EUR")
        kpi6.metric("N° Ribilanciamenti", str(result.n_rebalancing_events))
        kpi7.metric("Turnover Medio", f"{result.avg_turnover_per_rebalancing:.1%}")

        # ── Equity Curve ───────────────────────────────────
        st.subheader("📈 Equity Curve — Netta vs Benchmark")
        fig_equity = go.Figure()
        fig_equity.add_scatter(
            x=result.equity_curve_net.index,
            y=result.equity_curve_net.values,
            name="Portafoglio (netto)",
            line=dict(color="#4CAF50", width=2),
        )
        fig_equity.add_scatter(
            x=result.equity_curve_gross.index,
            y=result.equity_curve_gross.values,
            name="Portafoglio (lordo)",
            line=dict(color="#2196F3", width=1, dash="dot"),
        )
        st.plotly_chart(fig_equity, use_container_width=True)

        # ── Contributi per asset ────────────────────────────
        st.subheader("📊 Contributo per Asset")
        fig_contrib = px.area(
            result.asset_contributions,
            title="Valore per Asset nel Tempo (EUR)",
        )
        st.plotly_chart(fig_contrib, use_container_width=True)

        # ── Log Ribilanciamenti ─────────────────────────────
        if not result.rebalancing_log.empty:
            st.subheader("🔄 Log Ribilanciamenti")
            st.dataframe(
                result.rebalancing_log.style.format({
                    "from_weight": "{:.1%}",
                    "to_weight": "{:.1%}",
                    "delta_eur": "{:+.0f} EUR",
                    "cost_eur": "{:.2f} EUR",
                }),
                use_container_width=True,
            )
```

**Definition of Done — Sessione 6:**

```
□ Q15 appare nel menu navigazione Streamlit
□ Backtest manuale 4 asset 5 anni: < 15s end-to-end incluso fetch
□ Normalizzazione automatica pesi se sommano ≠ 1.0
□ Equity curve mostra linea netta e lordo distinguibili
□ Log ribilanciamenti vuoto se n_rebalancing_events = 0 (no errori)
□ Pagina carica senza eccezioni con fixture dati sintetici
□ pytest -m regression: 0 failed
□ pragma: no cover su Q15 (UI page — non testare direttamente)
□ Aggiornare .claude/06_pages_map.md con Q15
```

---

## 📅 SESSIONE 7 — Q14 Strategy Lab Aggiornato + Regime Backtest UI (1–2h)

**Obiettivo:** Aggiornare Q14 Strategy Lab con regime-conditional backtesting
e confronto multi-strategia visivo

**NON toccare:** Q1_Backtesting.py, Q15 appena creato

**File da modificare:**

```
presentation/dashboard_engine/pages/
  Q14_Strategy_Lab.py          ← MODIFICA: aggiungere regime-conditional section

presentation/ui/components/
  regime_performance_table.py  ← NUOVO: tabella performance per regime
```

**Spec aggiunta a Q14_Strategy_Lab.py:**

```python
# Aggiungere sezione "🎯 Backtest Regime-Conditional" a Q14

st.divider()
st.subheader("🎯 Backtest Regime-Conditional")
st.caption(
    "Ogni regime di mercato usa una strategia diversa. "
    "Il regime è calcolato con dati disponibili al momento del segnale (no look-ahead)."
)

with st.expander("⚙️ Configura strategie per regime", expanded=True):
    col_bull, col_bear, col_trans, col_stress = st.columns(4)
    with col_bull:
        st.markdown("**🟢 Bull**")
        bull_strategy = st.selectbox("Strategia", ["MA Cross", "Momentum", "Custom"], key="q14_bull")
    with col_bear:
        st.markdown("**🔴 Bear**")
        bear_strategy = st.selectbox("Strategia", ["Momentum Reversal", "RSI", "Custom"], key="q14_bear")
    with col_trans:
        st.markdown("**🟡 Transition**")
        trans_strategy = st.selectbox("Strategia", ["RSI Neutral", "MA Cross", "Custom"], key="q14_trans")
    with col_stress:
        st.markdown("**⚫ Stress**")
        stress_strategy = st.selectbox("Strategia", ["Cash (Flat)", "Short Only"], key="q14_stress")

if st.button("▶️ Esegui Backtest Regime-Conditional", key="q14_regime_run"):
    with st.spinner("Rilevamento regime e backtest in corso..."):
        # 1. Rileva regime (dall'HMM pipeline)
        # 2. Mappa strategie selezionate
        # 3. RegimeStrategySelector.generate_signals()
        # 4. RealisticBacktester.run() con i segnali combinati
        # 5. Mostra equity curve + breakdown per regime
        pass

    # Tabella performance breakdown per regime
    st.subheader("📊 Performance per Regime")
    # regime_performance_breakdown() → DataFrame
    # Mostra: regime, n_days, avg_daily_return, sharpe, positive_days_pct

    # Confronto: regime-conditional vs singola strategia uniforma
    st.subheader("⚖️ Confronto vs Strategia Unica")
    # Mostra che la strategia regime-conditional batte le strategie singole
    # almeno nel periodo di test (caveat: overfitting possibile)
    st.caption(
        "⚠️ Attenzione: la selezione post-hoc delle strategie per regime può "
        "portare a overfitting. Validare sempre con walk-forward out-of-sample."
    )
```

**Definition of Done — Sessione 7:**

```
□ Q14: sezione regime-conditional visibile e funzionante
□ RegimeStrategySelector integrato via import locale (NON in shared)
□ Regime breakdown table: 4 righe (una per regime) con sharpe
□ Warning anti-overfitting visibile in UI
□ Confronto vs singola strategia: equity curve affiancate
□ pytest -m regression: 0 failed
□ Pagina Q14 carica in < 3s con dati sintetici
```

---

## 📅 SESSIONE 8 — Drift Monitor + Aggiornamento P2 eToro (1–2h)

**Obiettivo:** Aggiungere il drift monitor alla pagina P6 Profilo Investitore
e collegare il SmartRebalancer alla pagina P2 Portfolio eToro

**NON toccare:** P2_Portafoglio_eToro.py (solo estensione), P5_Goals.py

**File da creare/modificare:**

```
personal/allocator/
  drift_monitor.py             ← DriftMonitor (salva snapshot, legge serie storica)

presentation/dashboard_personal/pages/
  P6_Profilo_Investitore.py    ← MODIFICA: aggiungere sezione "Smart Rebalancing"
  P2_Portafoglio_eToro.py      ← MODIFICA: aggiungere drift chart e alert fiscale
```

**drift_monitor.py:**

```python
# personal/allocator/drift_monitor.py
"""DriftMonitor: traccia l'evoluzione del drift nel tempo.

Salva uno snapshot del drift per ogni asset ogni giorno.
Permette di visualizzare come i pesi si allontanano dal target nel tempo.
Utilità: capire quanto spesso e quanto velocemente il portafoglio deriva.

Persistenza: db/user_sessions.db (tabella: portfolio_drift_history)
Retention: max 365 snapshot per profilo (pulizia automatica)
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, datetime
import sqlite3
from pathlib import Path
import pandas as pd
import structlog

log = structlog.get_logger(__name__)
DB_PATH = Path("db/user_sessions.db")
MAX_SNAPSHOTS = 365


@dataclass
class DriftSnapshot:
    """Snapshot del drift in un dato momento."""
    snapshot_date: date
    profile_id: str
    asset_drifts: dict[str, float]   # {ticker: drift_pct}
    max_drift: float
    needs_rebalancing: bool          # basato su SmartRebalancer


class DriftMonitor:
    """
    Monitora e persiste il drift del portafoglio nel tempo.

    Uso (chiamato giornalmente dallo scheduler):
        monitor = DriftMonitor()
        monitor.record_snapshot(
            profile_id="user_001",
            current_weights={"SPY": 0.45, "GLD": 0.25, "TLT": 0.30},
            target_weights={"SPY": 0.40, "GLD": 0.30, "TLT": 0.30},
        )
    """

    def __init__(self, db_path: Path = DB_PATH) -> None:
        self._db = db_path
        self._init_schema()

    def _init_schema(self) -> None:
        with sqlite3.connect(self._db) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS portfolio_drift_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    snapshot_date TEXT NOT NULL,
                    profile_id TEXT NOT NULL,
                    ticker TEXT NOT NULL,
                    drift_pct REAL NOT NULL,
                    max_drift REAL NOT NULL,
                    needs_rebalancing INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_drift_profile_date
                ON portfolio_drift_history (profile_id, snapshot_date)
            """)

    def record_snapshot(
        self,
        profile_id: str,
        current_weights: dict[str, float],
        target_weights: dict[str, float],
        needs_rebalancing: bool = False,
    ) -> None:
        """Salva uno snapshot del drift. Mantiene max MAX_SNAPSHOTS per profilo."""
        today = date.today().isoformat()
        all_tickers = set(current_weights) | set(target_weights)
        max_drift = max(
            abs(current_weights.get(t, 0.0) - target_weights.get(t, 0.0))
            for t in all_tickers
        )

        with sqlite3.connect(self._db) as conn:
            # Inserisci snapshot
            for ticker in all_tickers:
                drift = abs(current_weights.get(ticker, 0.0) - target_weights.get(ticker, 0.0))
                conn.execute("""
                    INSERT OR REPLACE INTO portfolio_drift_history
                    (snapshot_date, profile_id, ticker, drift_pct, max_drift, needs_rebalancing)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (today, profile_id, ticker, drift, max_drift, int(needs_rebalancing)))

            # Pulizia: mantieni max MAX_SNAPSHOTS giorni distinti per profilo
            conn.execute("""
                DELETE FROM portfolio_drift_history
                WHERE profile_id = ?
                AND snapshot_date NOT IN (
                    SELECT DISTINCT snapshot_date
                    FROM portfolio_drift_history
                    WHERE profile_id = ?
                    ORDER BY snapshot_date DESC
                    LIMIT ?
                )
            """, (profile_id, profile_id, MAX_SNAPSHOTS))

        log.info("drift_monitor.snapshot_recorded",
                 profile_id=profile_id, max_drift=round(max_drift, 4))

    def get_drift_history(
        self,
        profile_id: str,
        days: int = 90,
    ) -> pd.DataFrame:
        """
        Ritorna la serie storica del drift.

        Returns:
            DataFrame con colonne: snapshot_date, ticker, drift_pct, max_drift
        """
        with sqlite3.connect(self._db) as conn:
            df = pd.read_sql_query("""
                SELECT snapshot_date, ticker, drift_pct, max_drift, needs_rebalancing
                FROM portfolio_drift_history
                WHERE profile_id = ?
                AND snapshot_date >= date('now', ? || ' days')
                ORDER BY snapshot_date ASC
            """, conn, params=(profile_id, f"-{days}"))
        return df
```

**Definition of Done — Sessione 8:**

```
□ DriftMonitor.record_snapshot(): inserisce in DB correttamente
□ Pulizia automatica: max 365 snapshot per profilo (test verifica)
□ get_drift_history(): ritorna DataFrame con colonne corrette
□ P6_Profilo_Investitore: sezione "Smart Rebalancing" con:
    - Soglia dinamica corrente (basata su regime live)
    - Raccomandazione SmartRebalancer
    - Chart drift storico (ultimi 90 giorni)
□ P2_Portafoglio_eToro: alert fiscale quando vendita genererebbe plusvalenza > 500 EUR
□ pytest -m regression: 0 failed
□ DB user_sessions.db: tabella portfolio_drift_history presente
□ Scheduler APScheduler: job giornaliero record_snapshot registrato
```

---

## 📅 SESSIONE 9 — Validazione Finale, Vault v4.0 e CLAUDE.md v4 (1–2h)

**Obiettivo:** Validazione end-to-end su hardware reale, aggiornamento documentazione

**NON toccare:** architettura implementata nelle sessioni precedenti

**Attività:**

```
1. Test hardware reale Ryzen 5 5600:
   □ Q15 Portfolio Backtest: 4 asset × 5 anni → < 15s
   □ Q14 Strategy Lab: regime-conditional backtest AAPL → < 30s
   □ P6 Profilo Investitore: SmartRebalancer con regime live → < 1s
   □ P2 Portfolio eToro: alert fiscale visibile quando applicabile

2. Validazione boundary architetturale:
   □ tests/architecture/test_layer_boundaries.py: 0 failed
   □ grep -r "from engine.analytics" personal/ → solo via bridge
   □ management_ui.py: import check → nessun import engine/personal/shared

3. Aggiornamento CLAUDE.md → v4:
   □ Sezione "Moduli Chiave":
       - PortfolioBacktester: interfaccia e uso
       - RegimeStrategySelector: shift regime critico documentato
       - SmartRebalancer: threshold dinamica e regime
       - TaxAwareRebalancer: solo in personal/, calcola IT 26%
       - DriftMonitor: snapshot giornaliero, retention 365gg
       - CapitalGainsEstimator: FIFO, tax-optimal-sell-order
   □ Sezione "Feature Deprecate": lista con motivo deprecazione
   □ Sezione "Mappa Pagine": Q15 aggiunta, Q14 nota "regime-conditional"
   □ Sezione "Dipendenze Pinnate": conferma invariate

4. Creazione Vault v4.0:
   □ Modules/Portfolio Backtester.md — NUOVO
   □ Modules/Regime Strategy Selector.md — NUOVO
   □ Modules/Smart Rebalancing Engine.md — NUOVO (include Tax-Aware + Drift Monitor)
   □ Modules/Capital Gains Estimator.md — NUOVO
   □ Modules/Backtesting Strategies.md — AGGIORNARE (aggiungere regime-conditional)
   □ Modules/Portfolio Optimization.md — AGGIORNARE (collegare SmartRebalancer)
   □ Modules/Realistic Backtester.md — AGGIORNARE (link a PortfolioBacktester)
   □ config/feature_flags.yaml → aggiornare sezione deprecati
   □ index/Home.md → aggiungere nuovi moduli
   □ CLAUDE.md nel vault → v4
```

**Checklist validazione hardware finale:**

```
PORTFOLIO BACKTESTING:
□ PortfolioBacktester.run() [SPY, GLD, TLT, QQQ] 2019-2024: < 15s
□ equity_net.iloc[-1] < equity_gross.iloc[-1] (costi non nulli)
□ rebalancing_log non vuoto (ribilanciamenti avvenuti)
□ Q15: caricamento pagina < 3s con dati precedentemente scaricati

REGIME STRATEGY:
□ RegimeStrategySelector: segnali generati senza errori su AAPL 5 anni
□ Q14: regime breakdown table mostra 4 righe con sharpe diversi
□ regime_shifted[0] = "transition" (non usa dati futuri — verificato a mano)

SMART REBALANCING:
□ SmartRebalancer: stress regime → soglia = 0.05 + 0.05 = 0.10 (verifica)
□ TaxAwareRebalancer: plusvalenza 1000 EUR → tax = 260 EUR
□ DriftMonitor: record_snapshot → tabella DB popolata
□ P6: soglia mostrata in UI corrisponde al regime live

FEATURE AUDIT:
□ feature_flags.yaml: lstm_model, transformer_model, ollama_narrative = false
□ hardware_warning.py: banner mostrato se N-BEATS abilitato
□ Nessun import attivo a LSTM/Transformer nelle pagine dashboard

NESSUNA REGRESSIONE:
□ poetry run pytest -m regression: 0 failed
□ E1, E6, K1, M3, Q1, P2: funzionanti con dati reali
□ mypy --strict su tutti i nuovi file: 0 errors
□ ruff check .: 0 warnings
□ pytest --cov --cov-fail-under=89: verde
```

**Definition of Done — Sessione 9 (= Definition of Done v16.0.0):**

```
□ PortfolioBacktester: funzionante su hardware reale
□ RegimeStrategySelector: look-ahead verificato assente
□ SmartRebalancer: threshold dinamica rispetta regime
□ TaxAwareRebalancer: calcolo IT 26% corretto
□ DriftMonitor: persiste su SQLite con retention
□ Feature audit completato: DL deprecati documentati
□ Q14: regime-conditional backtest disponibile
□ Q15: nuova pagina funzionante
□ P6 + P2: integrazione SmartRebalancer e alert fiscale
□ CLAUDE.md v4: aggiornato con tutti i nuovi moduli
□ Vault v4.0: 5 nuovi file Modules/, 3 file aggiornati
□ pytest -m regression: 0 failed
□ mypy --strict: 0 errors su tutti i nuovi file
□ coverage ≥ 89%
```

---

## 📁 Struttura File Finale v16.0.0

```
%APPDATA%\MarketAI\
├── engine/analytics/backtesting/
│   ├── portfolio/                          ★ NUOVO
│   │   ├── portfolio_backtester.py
│   │   ├── rebalancing_schedule.py
│   │   └── portfolio_backtest_result.py
│   ├── strategies/
│   │   └── regime_strategies.py           ★ NUOVO
│   └── regime_strategy_selector.py        ★ NUOVO
│
├── personal/allocator/
│   ├── smart_rebalancer.py               ★ NUOVO
│   ├── cost_benefit_analyzer.py          ★ NUOVO
│   └── drift_monitor.py                  ★ NUOVO
│
├── personal/tax/
│   └── capital_gains_estimator.py        ★ NUOVO
│
├── shared/
│   └── hardware_check.py                 ★ NUOVO
│
├── config/
│   ├── feature_flags.yaml                ★ AGGIORNATO (DL deprecati)
│   └── hardware_capabilities.yaml        ★ NUOVO
│
├── presentation/dashboard_engine/pages/
│   ├── Q14_Strategy_Lab.py               ★ MODIFICATO (regime section)
│   └── Q15_Portfolio_Backtest.py         ★ NUOVO
│
├── presentation/dashboard_personal/pages/
│   ├── P2_Portafoglio_eToro.py           ★ MODIFICATO (alert fiscale)
│   └── P6_Profilo_Investitore.py         ★ MODIFICATO (smart rebalancer)
│
├── presentation/ui/components/
│   ├── portfolio_equity_chart.py         ★ NUOVO
│   ├── rebalancing_log_table.py          ★ NUOVO
│   ├── asset_contribution_chart.py       ★ NUOVO
│   ├── regime_performance_table.py       ★ NUOVO
│   └── hardware_warning.py               ★ NUOVO
│
└── tests/
    ├── engine/backtesting/portfolio/      ★ NUOVO
    ├── engine/backtesting/
    │   ├── test_regime_strategy_selector.py  ★ NUOVO
    │   └── test_regime_conditional_backtest.py ★ NUOVO
    ├── personal/allocator/                ★ NUOVO
    │   ├── test_smart_rebalancer.py
    │   ├── test_cost_benefit_analyzer.py
    │   └── test_drift_monitor.py
    └── personal/
        └── test_capital_gains_estimator.py ★ NUOVO
```

---

## 📊 Metriche di Successo v16.0.0

| Metrica | Target | Hardware |
|---|---|---|
| PortfolioBacktester: 4 asset × 5 anni | < 15s | Ryzen 5 5600 |
| RegimeStrategySelector: 10 anni AAPL | < 5s | CPU |
| SmartRebalancer.check() | < 100ms | — |
| TaxAwareRebalancer stima fiscale | < 50ms | — |
| DriftMonitor.record_snapshot() | < 200ms | SQLite |
| Q15 caricamento pagina | < 3s | con dati in cache |
| Q14 regime backtest | < 30s | con fetch |
| Coverage nuovi moduli engine/ | ≥ 95% | — |
| Coverage nuovi moduli personal/ | 100% | — |
| Layer boundary violations | 0 | test architettura |
| pytest -m regression | 0 failed | SEMPRE |
| mypy --strict nuovi file | 0 errors | — |
| DL features deprecate in UI | 0 accessibili | feature_flags |

---

## 📝 Template Prompt Apertura Sessione Opus — v16

```
Leggi CLAUDE.md (v4 quando disponibile) e i file @.claude/ pertinenti prima di ogni codice.

=== SESSIONE N — [nome sessione v16] ===

Contesto ambiente:
  - Progetto: %APPDATA%\MarketAI\
  - Python: 3.12.10 (venv Poetry — NON 3.14.5 sistema)
  - Hardware: Ryzen 5 5600, 16GB RAM, NO GPU attiva (ROCm instabile)
  - Gate: poetry run pytest -m regression -q --tb=short → [N passed / 0 failed]

Task di questa sessione:
  [copiare dalla sezione SESSIONE N di questa roadmap]

File da creare:
  [lista dalla roadmap]

NON toccare:
  [lista dalla roadmap]

Vincoli speciali v16:
  - DL models (LSTM, Transformer): NON aggiungere import nei file attivi
  - feature_flags.yaml: non abilitare feature marcate DEPRECATED
  - PortfolioBacktester: CostConfig OBBLIGATORIO (Regola 23)
  - RegimeStrategySelector: regime SEMPRE shift(1) — verificare in test

Definition of Done:
  [copiare dalla sezione corrispondente]

Inizia con: poetry run pytest -m regression -q --tb=short → deve dare 0 failed
Poi: poetry env info → Python 3.12.x confermato
Poi: inizia il task.
```

---

## 🗺️ Visione Timeline Completa v11→v16

```
v11.0.0 (~3 settimane)   ✅ Installer + Management UI + CLAUDE.md v2
v12.0.0 (~3 settimane)   ✅ Data Provider Plugin System + CI/CD + MkDocs
v13.0.0 (~4 settimane)   ✅ Ensemble + FeatureBuilder + Fan Chart Q1
v14.0.0 (~5 settimane)   ✅ N-BEATS (CPU) + Realistic Backtester + FastAPI
v15.0.0 (~5 settimane)   ✅ pywebview UI nativa + Session Persistence + Drift Detection
v16.0.0 (~6 settimane)   ← QUESTA ROADMAP
  · Multi-Asset Portfolio Backtesting Engine
  · Regime-Conditional Strategy Selector
  · Smart Rebalancing (threshold dinamica + tax-aware)
  · Feature Audit (deprecazione DL inutilizzabili su CPU)
  · Q15 Portfolio Backtest (pagina nuova)
  · Q14 Strategy Lab (regime extension)
  · P2 + P6 integrazione rebalancing

TOTALE post-v11: ~26 settimane (~6.5 mesi) per raggiungere v16.0.0
```

---

> *MarketAI v16.0.0 · Roadmap Backtesting Pro + Smart Rebalancing*
> *Pianificazione: Claude Sonnet 4.6 · Implementazione: Claude Code Pro (Opus 4.8)*
> *Hardware: Ryzen 5 5600 · RX 6700 8GB (CPU-only) · 16GB RAM · Windows 11*
> *⚠️ Disclaimer: Software a scopo informativo. Non costituisce consulenza finanziaria.*
